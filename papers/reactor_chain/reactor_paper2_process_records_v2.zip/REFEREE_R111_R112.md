## R111 (D2243 steady helm pass, 23 Nov 2026) — round 1 NOT BALANCED (2 BLOCKER, 3 MAJOR, 2 MINOR); round 2 NULL — BALANCED
F1 L-H on lenient P_loss vs exhaust Psep (BLOCKER, fixed DEV-1); F2 negative Psep passes via Lengyel clamp (BLOCKER, DEV-2); F3 Psep/R
limit missing (DEV-3); F4 convention label (DEV-4); F5 synchrotron budget unverified (flagged); F6 grid count; F7 impurity iterations.
Consequence: correction D2243a on D2236-D2241 L-H passes.

## R112 (D2244 NT mode, 23 Nov 2026) — NOT BALANCED (N1 BLOCKER core radiation ~99% uncapped; N2 MAJOR P_net>0; N3 MAJOR profiles/synchrotron)
Fixed by DEVIATIONS (post-results, disclosed) and rescore; capped verdict CLOSED.
R112 paper round (Reactor Paper 3): NOT BALANCED - P1 eta-3 claim false (fixed), P2 'removes H-mode wall' overstated (made conditional),
P3 f_rad definition (added), P4 profile/synchrotron caveats moved to limits. All numbers otherwise verified against result files.
R112 final paper round: NULL — BALANCED (P1-P4 resolved).
