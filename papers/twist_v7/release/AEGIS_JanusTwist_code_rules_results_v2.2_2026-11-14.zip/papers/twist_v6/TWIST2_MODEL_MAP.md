# Twist-2 — model map (baseline), 14 Nov 2026, 13:15 CT. AI-assisted.

**Status:** a design map assembled from D323–D394 and today's literature check (D392). Computed numbers carry their D-note; everything
else is labelled estimate or open. Nothing new is scored here. Before any new number is computed, its rule is locked.
**End view (unchanged):** one no-scale field T = x + iy inflates the universe, sets the vacuum energy through its cliff, and fixes the
scales of everything after it; every claim is pre-registered and allowed to fail.
**Design rule:** each sector is an attractor or symmetry-protected, has one dial fixed by one dataset and tested on another, and
falls back to a working model if its bet fails.

## 1. Field content

| Field | Role | Mass / scale | Status |
|---|---|---|---|
| T = x + iy (Twist) | Inflaton (Re T); sets Λ via the cliff | m_inf = 5.0×10¹³ GeV; x_E ≈ 27–29.5 after capture | kept from v5 |
| χ, χ̄ (weight 3/2) | Trap x at x_E as it rolls past; later condense, pinning x | coupling λ 0.004–0.033 (D377); condensate v ≳ 10⁷ GeV (D390) | trapping kept; pinning OPEN |
| N₁,₂,₃ (right-handed ν) | Neutrino masses + thermal leptogenesis | M₁ ~ 10¹²–10¹³ GeV (D394) | NEW (replaces hidden σ) |
| a (light axion-like particle) | Cosmic birefringence only | m_a < H(recombination) ≈ 3×10⁻²⁹ eV; f_a sub-Planckian | NEW (separate from dark energy) |
| ψ (gravity-only fermion) | Dark matter | 4–45 PeV after D396's dilution (λ ≥ 0.01; D397); stable (gauged Z₂) | kept, mass shifted |
| SUSY-breaking sector (D292) | Light gravitino branch | m_3/2 ~ eV | kept |
| Removed | hidden σ sector; thawing x tail; Y-only global stabiliser | — | gone (D387, D323, D373) |

## 2. Supergravity skeleton (schematic)

K = −3 ln(T + T̄) + |χ|²/(T + T̄)^{3/2} + |χ̄|²/(T + T̄)^{3/2} + |N|² + |H|²… + K_a(a + ā)
W = W_cliff(T) [n ≈ 124.1] + λ M_P (T − T_E) χχ̄ + ½ M_R N N + y_ν L H N + W_a
Photon coupling: (c_γ α/8π)(a/f_a) F F̃ only (no a F² term, so no change of α).
The pinning of x after trapping is the open piece (D390: χ condensate, Higgs-branch mass λv).

## 3. Cosmic timeline

| Stage | What happens | Number | Source |
|---|---|---|---|
| Inflation | α = 1 plateau attractor | N* = 57.2, n_s 0.9651, r 0.0036, α_s ≈ −6.1×10⁻⁴ | D391 (+ −2/N² estimate) |
| End of inflation → kination | x's kinetic energy dominates (w ≈ 1) for ~3.5 e-folds | adds +1.5 e-folds to N* (no σ) | D391, D367b |
| Reheating | radiation share grows | T_RH ~ 5×10¹⁴ GeV | v5 |
| Leptogenesis | thermal N₁ decays | n_B/s up to ~10⁻⁷ possible (need 0.87×10⁻¹⁰) | D394 estimate |
| Matter freeze-out | x ≈ 3 | T ≈ 2×10¹³ GeV | D367b |
| Capture | x crosses x_E; χ produced, traps x | T ≈ 10¹²–10¹¹ GeV; entropy cost Δ ≈ 1 + O(10⁻³) | D384, D367b |
| Pinning | thermal χ trap holds x at x_E; χ condenses, x gets mass gv | v ≈ 10⁹ GeV, x_E ≈ 29.6; dilution D ≈ 40–900 | D396 PASS (estimate) |
| BBN → recombination | standard | — | — |
| After recombination | axion a rolls, rotates CMB polarisation | β ≈ 0.42°(c_γ/2π)Δθ | D393 relation |
| Today | dark energy = Λ = V_Twist(x_E) ∝ e^{−2n} | w = −1 exactly | D383 |

## 4. Dials (5 free + 1 derived) and what fixes each

| Dial | Fixed by | Then tested by |
|---|---|---|
| Cliff exponent n | Ω_Λ | — (scale only) |
| Heat share (0.65–0.8%) | derived from χ̃ decay after the cliff (D80–D82, D118); not free | n_s, r, α_s |
| x_E, λ | capture window | no α drift, no moduli problem (structural) |
| M₁, y_ν | n_B/s | Σm_ν, ordering, 0νββ |
| c_γ Δθ (axion a) | β | frequency independence, anisotropic birefringence |
| m_ψ | Ω_DM | ν/γ lines (IceCube-Gen2, LHAASO) |

## 5. Predictions (scorecard)

| Observable | Twist-2 | Current data | Status |
|---|---|---|---|
| n_s | 0.9651 | 0.9684 ± 0.0030 (CMB-SPA); 0.9728 ± 0.0027 (+DESI, ΛCDM) | 1.1σ / 2.9σ |
| r | 0.0036 | < 0.03–0.04 | OK; LiteBIRD reaches ~10⁻³ |
| α_s | −6.1×10⁻⁴ | not yet sensitive | future |
| w(z) | −1 | DESI 2.3–4.2σ hint of evolution | baseline bet: hint fades |
| β | fitted (one knob) | 0.26 ± 0.06° | needs calibration; spectrum/frequency tests |
| varying α, fifth force | none | tight bounds | passes by symmetry and by capture |
| isocurvature | none (thermal leptogenesis) | Planck limits | passes (D320/D360 tests become moot) |
| Σm_ν | normal ordering, ≈ 0.06 eV | < ~0.07 eV | OK |
| dark matter | 4–45 PeV gravity-only fermion, stable (D397) | no signal expected | allowed; no decay signal |

## 6. Fallbacks (nested, so no single failure kills the model)

- DESI's evolution confirmed by a non-DESY5 SN sample at ≥ 3σ → switch on the variant in which a single aligned axion is both dark
  energy and the birefringence field (D393: PASS vs PantheonPlus at f ≈ M_P, c_γ ≈ 10). Requires solving f_eff ~ M_P.
- β calibrated to 0 → drop axion a; nothing else changes.
- n_s ≥ 0.972 from the CMB alone (SO, 3σ) → the inflation bet fails; recorded hedge: a kinetic pole of order p ≈ 3 (n_s 0.974),
  which changes the end view's no-scale Kähler potential.
- Pinning (D390) fails → heavy modulus decaying before BBN (costs N*, so n_s drops; must be computed before adoption).

## 7. Open problems (priority order)

1. Pinning of x after capture: D396 PASS at estimate level (x_E ≈ 29.6, v ≈ 10⁹ GeV, D ≈ 40–900). Remaining: field-theory check of the thermal trap and condensation; recompute the DM window with D.
2. Heat share: already derived (D118); no action. DM window recomputed with dilution (D397): 4–45 PeV, stable.
3. Tie m_ψ to a Twist scale (turns the DM window into a prediction).
4. String origin of axion a (a second Kähler modulus axion is the natural candidate) and of (T − T_E) (D388).
5. Decisive data check: n_s refit in an evolving-dark-energy background (PC cobaya).
6. Finish D367 with the stiff solver (D7).

## 8. What this gives up, honestly

- Matter genesis "through the angle" and its isocurvature signature (a distinctive v5 feature) are replaced by standard leptogenesis.
- The thawing dark-energy tail is gone in the baseline; w = −1.
- β is fitted, not predicted, in the baseline.
In exchange: no varying-α problem, no moduli problem if pinning works, one fewer hidden sector, and each remaining bet can fail
alone.

## 9. Test calendar

- Now: likelihood refit of n_s with evolving dark energy (PC); D390 pinning; D367 completion.
- 2026–27: DESI DR3 / Euclid BAO (watch already scheduled); ACT/SPT birefringence calibration.
- 2027–30: Simons Observatory n_s (±0.0015), r, calibrated β.
- 2030s: LiteBIRD r ~ 10⁻³ and β; IceCube-Gen2 DM; 0νββ.

## 10. Bridge (null) tests — locked D403

| Bridge | Balance condition | Twist value | Status |
|---|---|---|---|
| 1. Inflation (N* cancels) | B1 = r − 3(1−n_s)² = 0; B2 = α_s + ½(1−n_s)² = 0 | B1 = −0.9×10⁻⁴ (tol 1.2×10⁻⁴); B2 = +1.5×10⁻⁷ | awaits LiteBIRD/SO; imbalance kills the plateau class |
| 2. Dark energy ↔ clocks | (α̇/α)/[H₀√(3Ω_DE(1+w₀))] = ζ ≈ 3–6×10⁻³ (rolling modulus) | measured (4.4 ± 6.2)×10⁻⁹ | out of balance by ~5×10⁵σ: no rolling modulus (why Twist-2 uses Λ or an axion) |
| 3. Birefringence ↔ dark energy | β² = 2.5×10⁻³ (c_γ/f)² (1+w₀) deg² | balanced at c_γ/f ≈ 10–13 | measures c_γ/f today; a test once a second arm (reionization-era β) exists |
| 4. Reionization ↔ recombination birefringence | ρ_β = β_reio/β_rec = 1 − ε, ε ≤ 3.5×10⁻³ (single DE axion) | computed (D404) | awaits LiteBIRD; ρ ≈ 1 also from miscalibration, so it separates late vs early fields, not signal vs systematic |

**Centre check D406:** pinning dilution lowers N* by ⅓ ln D; best balanced point (λ 0.033, v 10¹¹ GeV, D 4.7) gives N* 56.7, n_s 0.9648 — misses the 0.5 e-fold tolerance by 0.02. With pinning, the inflation row reads N* 56.0–56.7, n_s 0.9643–0.9648.

**Cycle 1 (D407, CONFIRMED, conditional):** x decays through the U(1)_X gauge channel of the χ condensate (T_d ≈ 10⁹–10¹³ GeV), so the pinning dilution is D ≈ 1. N* stays 57.2 (n_s 0.9651), DM stays 100–200 TeV, leptogenesis needs only the observed yield. Conditions: decay products not dark radiation; Higgs-branch field theory; U(1)_X anomaly-free.

**Cycle 5 (D412, CONFIRMED):** x's hidden decay products give ΔN_eff ≈ 0.03 (MSSM g*) – 0.09 (SM g*), below ACT's 0.14; prediction testable by SO/CMB-S4. Condition (i) of D407 passes.

**Cycle 7 (D414, CONFIRMED estimate):** the baseline birefringence axion is natural: c_γ ≈ 1.6–3.9, f ≤ 0.1 M_P, Ω_a ≤ 3×10⁻³, mass 3×10⁻³³–3×10⁻²⁹ eV; if m ≳ 20 H0 it predicts β_reio/β_rec < 1 (LiteBIRD can separate it from the dark-energy axion and from miscalibration).

**Cycle 9 (D416, CONFIRMED):** total extra radiation (light gravitino + hidden decay products) ΔN_eff ≈ 0.08 (0.05–0.10) < 0.14; requires m_3/2 ≤ 4.7 eV. Prediction for SO/CMB-S4.

**Crown + Route A (D410, D419, CONFIRMED with label):** the crown (CMB-SPA+DESI+Pantheon+) rejects the undeformed Twist n_s 0.9651 (Δχ² 7.95). One tiny holomorphic term (ε = 3.0×10⁻⁷, K unchanged) gives n_s 0.9736; then every sense fits better than ΛCDM. New locked inflation predictions: r = 0.0046, α_s = −7.7×10⁻⁴, B1 = +2.5×10⁻³ (n_s now fitted).

**Cycle 12 (D422, CORRECTION):** on the Higgs branch x's decay products get mass m_ψ = y v ≈ 5×10⁵–10⁹ GeV and must decay to the SM (lepton mixing) or they would overclose. So the hidden-pair ΔN_eff vanishes: total ΔN_eff ≈ 0.02–0.06 (gravitino only), replacing 0.05–0.10. Twist-2 paper v1 table to be corrected in v2.

**Cycle 16 (D426, CONFIRMED estimate):** the χ trap needs the hidden sector warm at capture: the ψ–lepton portal with y' ≳ 5×10⁻³ keeps it in equilibrium (mixing ~2×10⁻⁶), or a separately reheated hidden bath with T_h ≥ 0.21 T suffices.

**Cycle 17 (D427, CLARIFICATION):** Twist-2 does not solve the cosmological-constant problem: the χ condensate's soft vacuum energy (~10²⁶–10³² GeV⁴) must be cancelled by the same one-off tuning as the SUSY-breaking energy (D292); only the leftover x-dependent piece is the cliff value set by n.

**Cycle 18 (D428, CONFIRMED):** baseline birefringence axion: β_reio/β_rec ≈ 1 for m ≲ 10 H₀, 0.24–0.66 at 50 H₀, ≈ 0 for m ≥ 100 H₀; distinguishable from a dark-energy axion or miscalibration for m ≳ 30–40 H₀.

**Cycle 20 (D430, CONFIRMED):** gravitino window 1 eV ≲ m_3/2 ≤ 4.7 eV (SUSY breaking √F ≈ 65–140 TeV); total ΔN_eff ≈ 0.02–0.06 (gravitino only, after D422).

**Cycle 21 (D431, requirement):** the ψ–lepton portal must be L-conserving (Dirac pair) and its lepton-coupled partner U(1)_X-neutral (mirror pair for anomaly freedom); otherwise the heavy ψ would give neutrino masses 0.8 eV–0.6 MeV.

**Deep study (D436–D437, conditional):** candidate origin of the capture coupling = moduli-dependent FI term on a magnetised D7-brane (x_E quantised by flux integers). In a locked toy it captures and pins the Twist by itself (D-term wall + soft-mass slope; settles by T ≈ 2–6×10¹⁰ GeV). Valid only where the D7 sector exists (x ≳ 1); the inflation region needs another description.

**Deep study step 3 (D438, toy):** with the stringy (Π-stability) FI term the small-volume blow-up disappears (|ζ| ≤ 0.37 M_s² for all x < x_E vs −76 M_P² naively); the FI-term origin of the capture coupling now survives from inflation to capture at toy level.

**Centre-confirmed (D439):** the condensate that screens the stringy FI term shifts n_s by ≤ 6e-6 and r by ≤ 1.3e-6; clean pass needs M_s ≲ 0.1 M_P (otherwise only a constant amplitude offset).

**Centre-confirmed (D441, toy):** stringy-FI capture holds (hard wall, soft slope 2.2× D437 at M_s = 0.1 M_P); with D439 the toy prefers M_s ≈ 0.068–0.1 M_P (≈ 1.6–2.4e17 GeV) for flux pair (10, 400).

**Open condition (D444):** in the FI picture the screening field φ must decay to lighter hidden states (τ < 1 s), or its non-adiabatic remnant at capture would overclose by ~1e6 (D444a) — decay is required.

**Sharpened (D445):** the decay must break the D7 charge (goldstino channel only moves it): lightest charged state ≲ TeV and annihilating, or D-instanton breaking.

**Centre-confirmed (D446, cloud run):** stringy-FI capture holds for M_s = 0.03–0.3 M_P (toy window with clean plateau 0.03–0.1 M_P); bounce-generated φ remnant makes the D445 removal conditions mandatory.

**Centre-confirmed (D447, cloud run 2):** the φ-sector remnant is removed by hidden annihilation if the lightest D7-charged state is ≲ 10 TeV (to 1%) or ≲ 100 TeV (as all of DM), λ ≲ 3, hidden bath T_h/T ≈ 0.1.

**Centre-confirmed (D449):** geometry check: the volume at capture gives M_s ≈ 1.1–1.7e17 GeV (g_s 0.1–0.5), inside the dynamical window 0.03–0.1 M_P. Open: redo the plateau test with volume-dependent M_s.

**Flag (D450):** the inflationary point sits at volume 𝒱 ≈ 4e-6 in string units (M_s ≫ M_P there); inflation is outside geometric control unless a T-dual/other description is shown.

**Flag detail (D451):** T-duality would restore control (dual volume 1.9e6) only with a modular F; the Twist's cliff breaks modularity by ~1e120, and a modular completion would mirror the cliff to x ≈ 0.034.

**Centre-confirmed (D452):** with the modulus normalised so 𝒱 = 1–10 at the CMB point (allowed Kähler rescaling), capture still holds (M_s ≈ 7e13–3.5e14 GeV); D450 flag downgraded to marginal control (α′ corrections at 𝒱 ~ 1–10 unchecked).

**Narrowed (D453):** KK tower after inflation limits the rescaling to a ≈ 3.8e3–7.9e3 (𝒱 ≈ 1–2.9 at the CMB point, m_KK/T ≈ 3–6): marginal on both ends.

**Condition (D458):** no KK parity; few light KK species; the a ≈ 3.8e3 end of the D453 band is preferred (ΔN_eff +0.005 per species vs +0.021 at 7.9e3).

**Centre-confirmed (D460):** even a gravity-mediated eV soft mass pins the field before BBN (return at ≈ 240 GeV, as predicted by D459's √m_s law); no direct SUSY-breaking coupling for φ needed.

**Condition (D461–D462):** SM on D3s/small blow-up; hidden FI D7 on a small divisor that intersects the Twist's large divisor → fibred (non-swiss-cheese) Calabi–Yau.

**Centre-confirmed (D463):** hidden radiation adds ΔN_eff ≈ 0.013 → total ≈ 0.065–0.081 (< 0.14); requires condensate energy share ε_h ≤ 5.5e-5.

**Centre-confirmed (D467):** in the rescaled geometry the bounce injection is tiny (ε_h ≤ 3e-8); with a gravity-mediated eV soft mass the φ remnant is ~0.6% of DM without any annihilation.

**Centre-confirmed (D476):** the kink at the D-term wall pins the Twist against any matter source (threshold ≥ 7e25 g/cm³): no fifth force or EP violation even with universal coupling.

**Centre-confirmed (D477–D478):** our vacuum has a lower-Λ neighbour (x ≈ 135, Λ₂ ≈ 0.23Λ) but tunnelling action S ≥ 1e10 (stable); φ is heavy during inflation (no isocurvature).

**Centre-confirmed (D480, D481, D483):** sgoldstino decays before BBN; gauged B−L strings (if present) Gμ ≈ 2e-17–8e-16 (possible future GW signal); capture robust to ×0.5–×2 kinetic energy (T_cap ≈ 5e8–9e11 GeV).

**Variant Twist-M (D490–D491, duality-symmetric):** F_sym = G(x) + x²G(1/x), V(1/x) = V(x); Λ and the capture at the self-dual point x = 1 (n = 233.9); with ε = 1.6e-7 fitted: n_s 0.9736, r 0.0045, α_s −8.0e-4 (same as Route A). Capture-side numbers not yet redone.

**Twist-M update (D492–D499):** w₀ = −1.0000, w_a ≈ 0; n = 234.05; kination 3.3 e-folds (ΔN* +0.89, ε re-fit pending); fifth force needs the FI kink, but then the FI soft energy controls the history (case (i), capture at x = 1, run pending) — the tracker self-relaxation holds only without FI.

**Twist-M predictions (D501):** n_s 0.9736 (fit), r = 0.00435, α_s = −7.6e-4, w₀ = −1, w_a ≈ 0.

**Twist-M link (D502):** one τ≈40 cycle may set both Λ (n = 234) and the axion mass (n/S = 0.93, k = 1) → axion at heavy end → LiteBIRD: β_reio ≈ 0, β_rec = 0.28° (mild support).

**Twist-M (D504):** string scale 2.65e15 GeV ≈ gauge meeting point 2.4e15 GeV (couplings within ~5% at M_s); requires D-brane unification without light X-bosons (proton).

**Twist-M open (DEEP 11):** exact T-duality needs a toroidal-orbifold-type geometry; reconcile with D462's intersecting-divisor requirement (candidate: IIB orientifold of T⁶/Z_N' with blow-ups).

**Twist-M homes (DEEP 2.1b):** exact duality available for a heterotic orbifold T or an isotropic IIB complex-structure U (both K = −3 ln); FI term then independent of the Twist field → case (ii); the matter coupling β is the decisive open question.

**Twist-M case (ii) condition (DEEP 2.2):** the field still oscillates today (δφ ≈ 1e-4 M_P), so SM masses must be blind to it (β ≲ 1e-2–1e-3); in modular-flavour homes the dual modulus sets Yukawas, so a separate sector is required.

**Variant Twist-M-L (D505, split/lens):** dark duality field A + heavy SM-facing modulus B with lens μ²ΔAΔB → β_eff < β_B m_A/m_B ≤ 2e-28 (stability-guaranteed dilution); condition: A must not enter the SM Kähler metric or gauge kinetic functions directly.

**Twist-M-L (D506–D509):** B ≳ 100 TeV (or never displaced); lens automatically too weak to drag B; candidate home: A = U₃ (shape of the torus the SM D7-branes do not wrap), SL(2,Z)_{U₃} exact, SM blind to U₃ at leading order; cliff from mirror-instanton corrections (n ≈ 2π×37).

**D512 (doubt):** the single-torus home (k = 1) reaches n_s ≈ 0.970 (r ≈ 1.3e-3) before the inflation solution jumps branch; no clean fit at 0.9736 shown — D508 home in doubt; k = 3 needs all three tori (then the SM couples).

**Variant Twist-1T (D513, single torus, no fitted tilt):** n_s 0.9658, r 0.00116, α_s −6.7e-4, n 232.8; fits CMB-SPA (−0.9σ), not SPA+DESI (−2.6σ). Most predictive version; LiteBIRD should see no r.

**SERAPIS — the fully modular Twist (named by Danny 21:34 CT; D515, roadmap A):** exact SL(2,Z); inflation on the cusp gives n_s 0.9665, r 0.0032 (Starobinsky-like); square torus = Minkowski vacuum, triangle point = wall; Λ term still to add.

**SERAPIS-1 (D517, single torus, fully modular):** n_s 0.9667, r 0.0011 (no tilt); vacuum at square torus with V = Λ and mass 4e13 GeV (stiff: no fifth force, no moduli problem); Λ coefficient e^{−121.6} (instanton-sized); triangle point = wall. Cleanest version so far; decided by the CMB-vs-DESI n_s question.

**SERAPIS status (D518, DEEP 2.3):** reheating gives N* ≈ 52 → n_s ≈ 0.962 (D517 'viable' withdrawn pending a faster decay channel); building block is prior art (2405.06497, 2407.12081) — no separate publication.

**SERAPIS-1 final predictions (D519–D520):** n_s 0.963–0.965, r 0.0012–0.0013, α_s ≈ −6.5e-4 (reheating-consistent); fits CMB-SPA, 2.8–3.7σ from SPA+DESI; no kination route.

**Janus paths inside SERAPIS (D519, D525):** Kairos n_s 0.963–0.965, r 0.0012–0.0013 (no fit); Chronos δ = 0.0023 → n_s 0.9736, r 0.0020, α_s −5.9e-4 (one fit). n_s is the main discriminator.

**CORRECTIONS AND CURRENT STATE (14 Nov 2026, 22:55 CT; D537–D557).** The SERAPIS and SERAPIS-1 entries above are superseded where they conflict:
- **Withdrawn:** "vacuum with V = Λ", "Λ coefficient c = e^{−121.6}". With a holomorphic W the τ = i vacuum is SUSY Minkowski (D537, D538); Λ is a separate, tuned sector, consistently the gauge-mediation X sector (D548).
- **The n_s/r numbers above were at the wrong N*.** Current values (own reheating, N* = 52–55.6): Kairos n_s 0.963–0.965, r 0.0012–0.0013; Chronos (δ = 0.0023) n_s 0.971–0.974, r 0.0020–0.0022 (D519, D526, D545, D546). Vacuum mass 4.2–4.5e13 GeV (D539).
- **Reference model is now SERAPIS-KL** (D545/D546): V in the nilpotent-field metric, I = (1/4π)ln(1+|j−1728|²/1728²). It is single-valued, with its V = 0 minimum at i and regular at ρ. SERAPIS-1's holomorphic H is outside the string class and multi-valued around ρ (D535, D543).
- **Prior art:** Kallosh–Linde 2408.05203, 2412.19324, 2512.02969, 2411.07552; Casas–Ibáñez 2407.12081; Abe et al. 2303.02947. The inflation model is assembled from published ingredients (D556).
- **Home conditions:** factorised T² ⊕ T⁴, flux-free T², |b^{N=2}| ≲ 2, M_s ≳ 1e17 GeV (D530, D532, D553, D554). This is incompatible with Twist-2's low M_s, so SERAPIS and Twist-2 are separate realisations.
- **Proton:** Z₄^R/Z₈^R modular-centre parity, anomaly-checked, safe for m₃/₂ ≲ 100 TeV and compatible with the τ = i vacuum (D528–D533, D542, D551).
- **Twist-M case (i) FI trap:** NOT CAPTURED (D547).
