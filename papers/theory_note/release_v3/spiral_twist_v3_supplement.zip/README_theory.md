# theory/: scripts and outputs for the BI-supergravity theory note

Theory note: doi:[10.5281/zenodo.23898708](https://doi.org/10.5281/zenodo.23898708) (all versions) · source in
[../papers/theory_note/](../papers/theory_note/).

| Script | What it computes | Output |
|---|---|---|
| `bi_kahler_lambda.py` | Kähler metric of the Gates–Ketov–Yunes BI superfield; λ = −2√(2/3) (sympy) | `bi_kahler_lambda.json` |
| `bi_qcd_axion.py` | QCD-anomaly BI-axion potential scale and equality-era consistency estimate (Mercuri–Taveras normalization) | printed JSON |
| `solar_lowz.py` | Solar-system gate (Cassini) for the BI dilaton | `solar_gate.json` |
| `bi_superpotential.py` | Supergravity potential for constant W | `bi_superpotential.json` |
| `ufe_checks.py` | Inflation from α = 1; dilaton as early field; LQG value | `ufe_er.json`, `ufe_in.json` |
| `spiral_w.py` | Two-field Spiral Twist solver; validation; Ramos-Hamud mirror; scans; matter-like angle | `spiral_*.json` |
| `spiral_class_mirror.py` | AxiCLASS effective spiral against the solver | `spiral_class_mirror.json` |
| `forward_predictions.py` | Frozen predictions from the stored best fits | `forward_predictions.json` |
| `lowz_split.py` | DES Y5 supernova χ² split at z = 0.1 | `lowz_split.json` |

**Rules written before computing:** `PREREGISTRATION_UFE_CHECKS.md`, `PREREGISTRATION_SOLAR_LOWZ.md`.
**Predictions locked before the data:** `PREDICTIONS_LOCKED_2026-11-02.md`, with its SHA-256 in the `.sha256` file.

The constant-superpotential calculation is only an algebraic consistency check: its positive branch has a negative
signed logarithmic slope in the stated canonical-field orientation, its local minimum is not global, and it does
not derive the exponential or cosine terms assumed in the Spiral Twist model. Run the focused analytic regressions
with `python -m pytest theory/test_bi_supergravity.py`; the background solver's bounded consistency checks are
`python theory/spiral_w.py validate` (do not use `scan` as a validation substitute).

`bi_qcd_axion.py` independently evaluates the leading QCD-anomaly potential
$V=\chi_{\rm QCD}[1-\cos(\varphi/F_\varphi)]$, derives its curvature mass, and propagates the explicit susceptibility,
decay-constant, expansion, entropy, equality, and target-fraction inputs. Its equality-era angle estimate is relative
to the total density (matter plus radiation) and is valid only in the subdominant, small-angle approximation.
The zero-temperature susceptibility and fixed-degree-of-freedom assumptions are not a thermal QCD likelihood; the
resulting $n=1$ field oscillates as matter long before equality and is neither the AEGIS $n=3$ equality-locked EDE
potential nor late-time quintessence. The full derivation and limitations are in
`papers/theory_note/spiral_twist_note.tex`; input-scaling regressions are covered by
`python -m pytest theory/test_bi_qcd_axion.py`.

**Paths:** scripts that rebuild fits read `TWIST_AXI` (default: this repository's `cmb-fit/axiclass` inside WSL) and
`TWIST_RESULTS`. The pure-Python ones (`bi_kahler_lambda.py`, `solar_lowz.py`, `bi_superpotential.py`,
`ufe_checks.py`, `spiral_w.py`) need only numpy, scipy and sympy.
