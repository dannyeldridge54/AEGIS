## D2110 (DEEP, Seed v6): Z₂×Z₆′ AAA full positive control PASSES. Locked in PREREG_D2110, run once.
- **Result:** the Table 27 global Pati-Salam model (1209.3010) was rebuilt from scratch with the transcribed exceptional-wrapping table, the orientifold images and the AAA twisted tadpoles (η_(k) = −1).
  - Bulk tadpole = 32.
  - **All 24 twisted RR residuals are 0.**
  - The chiral intersections match Table 28 exactly with sign +1: ab 1, ab′ 2, ac −1, ac′ −2, bc 1, bd 1, bd′ −3, be′ −1, cd −1, cd′ 3, ce′ 1.
  - All other pairs are 0, so there are **no chiral exotics**.
  - That gives 3 + 3 PS families: a–b gives 1 + 2 left-handed, and a–c gives 1 + 2 right-handed.
- **Ordering:** P1 (cyclic) and P2 (increasing) both pass, so this model does not resolve the (j, k) ordering. Rule going forward: outward scans compute both and keep a model only if P1 and P2 agree. Any disagreement is flagged, not used.
- **Transcription:** the typo-corrected block-3 α₁ was declared in the PREREG before the run, and the control is consistent with it.
- **Verdict:** v6 exceptional layer VALIDATED (PHYSICS: reproduces a published global model). Next: D2111, an outward Z₂×Z₆′ scan with tadpole-solving plus the v4 α_s chain, under a new lock.

## D2105 L4 closeout (CENTRE): the Z₂×Z₂ outward run finished. **VERDICT B: FAIL**, as locked.
- **L4 (L = 5, 1728 χ points, 80,004 branes):**
  - 44 PS models, 8 of which fit;
  - 4 are exotic-safe;
  - **0 hits**.
- **Best |Δα_s|** among the exotic-safe models stays at **0.0557 at every level, L1–L4**. The search has converged, and widening does not help.
- **Backward pulse:** all 4 safe models are born at L1 (α_s = 0.0623, M_s = 1.6e11 GeV).
- **Conclusion:** the Z₂×Z₂ geometry is closed for this question. The work moves to Z₂×Z₆′, where v6 is now validated (D2110).

## D2111 (DEEP, Seed v6): outward Pati–Salam scan on Z₂×Z₆′ AAA. **Control PASS. The landscape collapses to ONE spectrum.** Locked, with DEVIATIONS (a memory fix only, written before the rerun).
- **Space:** visible a(4), b(2), c(2) on the same bulk wrapping (t = 2; 36 wrappings × 256 fractional labels), plus at most 2 hidden stacks (t ≤ 14). Filters:
  - all 24 twisted tadpoles and the bulk tadpole of 32 cancel;
  - the P1 and P2 orderings agree;
  - visible stacks are not their own images.
- **Results (2 cloud shards, about 5 min each):**
  - **Raw:** 5,184 visible triples give 3 + 3 families. Every one of them completes globally, for 8.96M raw models.
  - **Distinct by cycle data:** 5,184 per shard, with 432 distinct visible configurations per shard. The shards may overlap through (n,m) → (−n,−m) sign flips on two tori, so this is an upper bound.
  - **Control:** the Table 27 visible a, b, c is rediscovered (shard 1), with 1,728 raw hidden completions.
- **Spectrum:** every model has the Table 27/28 spectrum.
  - ab + ab′ = 1 + 2 and ac + ac′ = −1 − 2. The only other variant is the same with b ↔ c, i.e. the L ↔ R mirror.
  - χ(x, x′) = 0 for a, b, c, so there are no chiral sym/antisym exotics from the image term. The O6 term is still owed.
  - The visible–hidden |χ| total is 10, the same as Table 28.
  - The hidden sector is always 2 × U(2).
- **Reading (PHYSICS):** in this class (equal-volume visible stacks, at most 2 hidden stacks), the global 3-family PS model of 1209.3010 is **unique up to lattice relabelling and L ↔ R**. The many raw solutions are labels and symmetry images of one model. So the outward search on this geometry does not open a landscape. It points at one rigid model, which is the opposite of the Z₂×Z₂ exotics wall.
- **Next:** D2112. Write the Z₂×Z₆′ gauge-kinetic formula from the paper first, then run this one model through the v4 α_s chain (equal tree-level couplings, so sin²θ_W = 3/8 at M_s), plus the bd′/cd′ vector-like question.

## D2112 (DEEP, Seed v6): full derivation checklist K1–K11 for the unique Z₂×Z₆′ global Pati–Salam model. One staged run, locked. DEVIATIONS: a crash fix with no output seen, plus a K4 P2 addendum owed under the D2110 rule.

| # | Item | Result | Verdict |
|---|---|---|---|
| K1–K2 | Global consistency and chiral spectrum | D2110 | PASS |
| K3 | Sym/Anti chiral = ½Π∘Π′ | 0 for a, b, c, d, e. Consistent with the paper's "27 three-stack configurations, identical chiral spectrum" and with D2111 uniqueness | PASS |
| K4 | GS U(1) mass matrix | **P2 (increasing j<k) reproduces all 15 × 5 entries exactly. P1 fails in sector 2.** Rank 5 | PASS. **This settles the ordering ambiguity: P2 is the paper's convention.** D2111 stays valid because it required P1 = P2 agreement. A P2-only rescan could add models and is owed as a new lock |
| K5 | β coefficients (Tables 28+29) | b₄ = −2, b_L = b_R = +6, b_d = +28, b_e = +2 | Recorded |
| K6 | One-loop thresholds | The exact ϑ/η for f_a matches the paper's asymptote to 1e-7, which validates the normalisation. The paper's f_{b,c} line is internally inconsistent: with the literal 1/2π the v_m term grows, and with the corrected 1/2π² the v₃ slope is −1/48π against the stated asymptote's −1/16π. The unification condition comes out three ways: our exact-corrected v₁ = v₂ ≈ 5v₃/4 + 7 ln2/π (e.g. v₃ = 10 gives 14.04); the paper's asymptote gives v₃/4 + 7 ln2/π; the paper prints 4v₃ + 168 ln2/π, which **matches neither** | FLAG (possible typos in the source; "near-isotropic" survives qualitatively). Needs Honecker:2011sm to settle |
| K7 | String scale | α_tree⁻¹ = 3.53e-4 M_Pl/M_s, which reproduces the paper's ≈4e-4. Getting α_X⁻¹ = 24.33 needs M_s = 3.5e13 GeV (reduced M_Pl) or 1.8e14 (non-reduced), against M_GUT = 2.0e16 | **TENSION, a factor 114–569 in scale.** This is the known IIA M_s/M_GUT problem |
| K8 | α_s at one loop | S1 (MSSM only, PS broken at M_s = M_GUT): **0.1168, PASS** under the locked tolerance, but conditional on K7, which says M_s ≠ M_GUT at tree level. S2 (all PS-vector-like states at 1 TeV): α_X⁻¹ < 0, non-perturbative | S1 conditional PASS; **S2 FAIL**, so those states must be heavy |
| K9 | Yukawas | 1 perturbative generation. The other two need instanton suppression with S ≈ 5.6 (charm) and 11.8 (up) | ESTIMATE |
| K10 | PS breaking | No (4,1,2) Higgs in Tables 28/29 (ac and ac′ are the chiral families) | **OPEN.** Needs brane recombination or splitting |
| K11 | Hidden sector | All 5 U(1)s are massive, so there is no massless dark photon at this level. SU(2)_d (b = +28) and SU(2)_e (b = +2) are IR-free and do not confine | Recorded. **New cosmology flag:** 6 massless hidden gauge bosons (ΔN_eff, F7) unless they are broken. This changes the D2098 "dark SU(12)" picture, which belonged to the Z₂×Z₂ geometry |

**Overall:** the model is fully consistent as a string vacuum (K1–K4 PASS). Its phenomenology has 3 hard open items: K7 the scale tension, K10 PS breaking, K11 the massless hidden SU(2)s; plus the K6 literature inconsistency.
**Next queue:**
- D2113: P2-only rescan (the convention is now fixed);
- D2114: solve K7 with the full thresholds (v₁, v₂, v₃, g_s) against the measured couplings at M_s;
- D2115: a K10 recombination route.

## D2113 (DEEP): P2-only rescan. **Uniqueness survives.**
- The counts are identical to D2111: 2 × 2,592 visible triples, 2 × 4,478,976 raw, 5,184 distinct-by-cycle per shard.
- The Table 27 control is found.
- There is still exactly 1 spectrum, up to the L ↔ R mirror.
- So the P1 ∩ P2 requirement in D2111 removed nothing in this class.
- **Verdict:** the model is unique in its class under the settled convention.

## D2115 (CENTRE): Pati–Salam breaking route, logic check.
- The paper (p.tex around line 1452) says recombination or deformation needs adjoint multiplets.
- Tables 28/29 contain adjoints only for stack d (4 of them). There are none for a, b, c or e, and there is no (4,1,2)-type Higgs.
- **Verdict:** PS → SM breaking is **OBSTRUCTED perturbatively** for the rigid a and c stacks.
- **Routes still OPEN:**
  - (i) recombination involving the flexible hidden stack d;
  - (ii) non-perturbative (instanton-induced) Higgs couplings;
  - (iii) leaving the rigid-cycle class, i.e. a new geometry search.

## D2114: PRELIMINARY, under independent referee check. Not final.
- The isotropic case (v₁ = v₂) has no solution. The α₁ residual jumps between a branch with g_s ≫ 1 (M_s > M_Pl) and a branch with g_s < 1, and the jump is a branch switch, not a root.
- The general case only gives solutions with g_s > 1, or with |one-loop|/tree ≈ 0.85–0.99.
- The solver grid skipped 300 < v₃ < 1e4; the referee is checking that range.

## D2114a (correction to the preliminary D2114 note)
- The preliminary note said general solutions have only g_s > 1 or ctrl ≈ 0.85–0.99. That was **wrong**; it was an artefact of the coarse grid.
- The dense re-solve (D2116a) finds **geometric solutions**, with all v_i ≥ 1 and g_s < 1.
- The isotropic "no solution" statement stands.

## D2116 (CENTRE): settle pass 3. Locked.
### a. K7, dense re-solve
- **Variants:** 120 values of v₃ in [10, 1e6], for variants A/B and reduced/non-reduced M_Pl.
- **Geometric solutions** (v_i ≥ 1, g_s < 1) exist in every variant: 8, 2, 8 and 3 of them.
  - They are anisotropic, with v₃ ≈ 6e2–5e3 > v₁ ≈ 2e2–4e2 > v₂ ≈ 1e1–2e2.
  - They put M_s at 7e12–2e14 GeV, with g_s = 0.05–0.6.
- **Control:** **none has |one-loop|/tree < 0.3.** The best values are 0.318 (non-reduced, B) and 0.42 (reduced, B); variant A gives ≥ 0.78.
- **Isotropic:** no genuine root. On the g_s < 1 branch the α₁ residual stays at +4.6 to +8.6 and never crosses zero.
- **Verdict K7:** the measured couplings **can** be matched geometrically, but only at an intermediate string scale (~1e13–1e14 GeV), with strongly anisotropic tori and one-loop thresholds at ≥ 32% of the tree value. That is **MARGINAL / not under perturbative control** by the locked 0.3 criterion. α_s is an input here (a FIT), not a prediction.

### b. K11, ΔN_eff (ESTIMATE)
- 6 massless hidden SU(2) gauge bosons (g = 12), decoupling at M_s with g*s ≥ 228.75.
- That gives **ΔN_eff ≈ 0.12**, under the Planck+BAO 95% bound of ≈ 0.3. **PASS** (an upper estimate, assuming a thermal hidden sector).

### c. K-theory / FI, literature check
- p.tex sets up USp probes (lines 1315–1316) but gives no K-theory statement for this model, so we computed it ourselves (D2117).
- **FI / D-terms for the twisted moduli:** p.tex says nothing. **NOT VERIFIED.**

## D2117 (DEEP): K-theory probe check, computed. **PASS.**
- **Probe count:** 512 distinct orientifold-invariant fractional cycles; **256 of them supersymmetric, which matches the paper's 144 USp + 112 SO = 256 exactly.** This is an independent check of the engine.
- **Condition:** Σ_x N_x Π_x∘Π_p is even for **all 512 probes**, with 0 violations.
- **Verdict:** the model is K-theory consistent.

## SETTLED STATE (closing table for the paper)
| Item | Verdict |
|---|---|
| K1 | PASS |
| K2 | PASS |
| K3 | PASS |
| K4 | PASS (fixes the convention) |
| K-theory | PASS (D2117) |
| Uniqueness | PASS (D2111/D2113) |
| K5 | recorded |
| K6 | FLAG (inconsistencies in the source) |
| K7 | MARGINAL (fit only, ctrl ≥ 0.32) |
| K8 | S1 conditional / S2 FAIL |
| K9 | ESTIMATE |
| K10 | OBSTRUCTED perturbatively (D2115) |
| K11 | PASS (ΔN_eff ≈ 0.12, estimate) |
| FI / D-terms | NOT VERIFIED |

**The derivation is complete at this level.** Every item now has a verdict backed by evidence.

## D2118 (CENTRE, PHYSICS from literature plus D2112 K4): twisted-moduli FI / D-terms. NOT VERIFIED → PASS at the orbifold point.
- **Mechanism:** each anomalous U(1)_x gets an FI term linear in the Z₂^(k) twisted moduli, with exactly the Green–Schwarz coefficients c_x^{(k),α} of D2112 K4. This is the frozen-moduli mechanism of Blumenhagen–Cvetič–Marchesano–Shiu (hep-th/0502095).
- **At the orbifold point:** the twisted moduli are zero, so ξ_x = 0, and bulk SUSY (Y = 0) makes the fractional branes supersymmetric there.
- **Consequence:** because the c-matrix has rank 5 (K4), exactly 5 combinations of twisted moduli are lifted by the D-term potential. The vacuum at the origin, with ξ = 0 and charged scalars at zero vev, is supersymmetric.
- **Verdict:** **PASS** (consistent, SUSY vacuum at the orbifold point). 5 twisted moduli are frozen (literature mechanism).
- **Caveat:** away from the orbifold point, D-flatness would need charged-scalar vevs. Not studied here.

## D2119 (CENTRE): referee round 1 → fixes. Locked; all computed once.
The referee (negative pole) report R1-1 … R1-11 was NOT BALANCED, with 4 majors. Fixes:
- **R1-2 (normalisation, CONFIRMED by quote p.tex ~1816):** 4π/g² = 2π Re f. So δ(α⁻¹) = 2π Re δf, now primary.
- **R1-3:** the two-typo reading, where the expression equals the stated asymptote, is the consistent one. Variant A is primary and B is demoted.
- **R1-1:** SLSQP minimum of ctrl over the matching curve, every point re-verified with fsolve:
  - **primary (A, reduced, 2π):** min ctrl = **0.82** at v = (46, 1.0, 696), g_s = 0.002, M_s = 7.6e12. The minimum sits on the v₂ = 1 boundary. **NOT controlled.**
  - A, non-reduced: 0.77, not controlled.
  - B (demoted): 0.28 (reduced) and 0.22 (non-reduced), controlled.
  - With norm 1, the same ctrl values, but v is about 6× larger.
  - **K7 verdict: FAIL under the consistent reading.** This replaces "MARGINAL" in D2116; the earlier "≥32%" bound was also wrong (the coarse grid missed the minimum).
- **R1-4 / R1-5 (uniqueness):** uncapped P2 rescan, with the signature extended to ab, ab′, ac, ac′, bc, bc′, self-χ, hidden N, Σ|χ_vh| and per-stack |χ_vh|.
  - All 5,184 models per shard were checked (≤ 864 distinct visible triples).
  - There are **2 signatures, an L↔R pair**: bc = ±1, bc′ = 0, hidden 2 × U(2), per-stack vis–hid |χ| = (a 0, b 5, c 5).
  - Uniqueness holds under the precise wording: unique **chiral** spectrum in its class. "Up to lattice relabelling" is dropped.
- **R1-9:** the K4 P2 output is committed in z2z6p_round1_extra.txt: 0 mismatched rows.
- **R1-10:** ΔN_eff:
  - vectors only: 0.11, PASS;
  - plus hidden chiral fermions: 0.56, FAIL;
  - everything massless: 0.82, FAIL.
  - **K11 is now CONDITIONAL:** it needs hidden-sector masses (superpotential or soft) or a non-thermal hidden sector.
- **R1-6, R1-7, R1-8, R1-11:** fixed in the paper text.
  - K-theory: 256 invariant cycles up to orientation, a superset of the USp probes; only the totals match HRS.
  - The z₀ reading of the type-II formulas is disclosed (the literal reading fails the control: 7/24 residuals).
  - Tadpoles: 15 non-trivial + 9 identical.
  - The FI ledger is aligned with D2118.

## Housekeeping (R2-4)
The D2116 "K7 MARGINAL, ctrl ≥ 0.32" verdict and the D2116 settled-state table are **SUPERSEDED by D2119**: K7 FAIL, min ctrl 0.82 under the consistent reading.

## D2120 (DEEP, ping-pong fold-in): discrete Z_n remnants. **NEW OBSTRUCTION to the light-generation Yukawas.** Locked.
- **Triangulation:** both poles flagged this independently in the same minute. The referee raised R2-2 from Honecker arXiv:1303.6845, which says discrete Z_n from massive U(1)s are unbroken by D-brane instantons. The builder's own search led to the same paper.
- **Computation** (Berasaluce-González–Ibáñez criterion on the P2 GS matrix, N_x c_x):
  - **Z₂, Z₄ and Z₈ survive.** This holds with the raw c-values and with the doubled normalisation.
  - The perturbative Yukawa (ac·bc·ab) has Z_n charge 0 for every generator, so it is allowed.
  - **The three couplings needed for generations 2 and 3, ac′·bc·ab′, ac·bc·ab′ and ac′·bc·ab, are each FORBIDDEN by a surviving Z₄ (and Z₈).**
- **Reading (PHYSICS, conditional on the Z_n criterion and normalisation):**
  - No D-brane instanton, at any order, can generate the missing two generations' Yukawas from the bidoublet alone. So the K9 estimate S ≈ 5.6/11.8 does not apply.
  - The remaining routes are higher-dimensional operators with Z_n-charged singlet or hidden vevs, or a different Higgs sector.
- **K9 verdict:** was ESTIMATE, now **OBSTRUCTED (Z₄)**. The referee is asked to verify the criterion and the normalisation.
- **Six-stack note (R2-1):** the published six-stack PS model (p.tex:3625; 1303.6845) has 3 hidden stacks, so it lies outside our class. Uniqueness is relative to the "at most 2 hidden stacks" bound.

## D2120a (DEEP, correction to D2120 after referee R2-3): Z_n on the full even lattice.
- **What D2120 tested:** only the 16 *necessary* conditions of 1303.6845 Eq. (4.5). This version adds the sufficient conditions.
- **Lattice:** 7,223 distinct integral test vectors, from Π + Π′ over |n|, |m| ≤ 2 × 256 labels, plus the invariant cycles.
- **Survivors:**
  - **Z₂:** 31 generators;
  - **Z₄:** 96 generators (e.g. k = (0,1,1,1,1)), different from the D2120 example k = (0,0,1,1,1), which the referee showed breaks to Z₂;
  - **Z₈ does NOT survive.**
- **Yukawa selection under the surviving Z₄:**
  - ac·bc·ab (perturbative, generation 1): allowed.
  - **ac′·bc·ab′ (the 2×2 block for generations 2–3): ALLOWED.** Instantons can generate it.
  - **ac·bc·ab′ and ac′·bc·ab (generation 1 ↔ 2,3 mixing): FORBIDDEN** at all orders by instantons.
- **Correction to D2120:** "all three gen-2/3 couplings forbidden" was WRONG; it was a necessary-only test.
- **New K9 verdict:** the masses of generations 2 and 3 can come from instantons (the S ≈ 5.6 / 11.8 ESTIMATE is reinstated). But the **Yukawa matrix is block-diagonal, 1 ⊕ 2, to all instanton orders**, so generation 1 cannot mix with 2 and 3. Combined with the PS relation Y_u = Y_d from a single bidoublet, there is no Cabibbo mixing (V_us = 0) without extra Higgs fields or higher-dimensional operators with Z₄-charged vevs.
- **Status:** STRUCTURAL OBSTRUCTION (mixing), not a mass obstruction.
- **Caveat:** the lattice is truncated at |n|, |m| ≤ 2 for Π + Π′. A larger lattice can only remove survivors, not add them.

## D2120b (DEEP): Z_n on the exact integral even lattice. **SETTLED; both poles agree.**
- **Lattice:** F has rank 32 and **det Gram(ω) = 1**. It is unimodular, so F = H₃(Z) exactly, and the lattice is complete. E = F ∩ ker(R−1) has rank **16**, matching the 16 ΩR-even cycles of 1303.6845.
- **Calibration (six-stack model of 1303.6845):**
  - The code independently recovers the massless U(1)_Z = Q_b − Q_c + Q_e + Q_f (its rows vanish on E).
  - Every Z_n survivor for n = 2…8 (63/2/448/4/126/6/512 of them) is trivial (centre-type or Q_Z). The locked criterion PASSES and matches §5.1 of the paper.
- **Five-stack model:** Z₂ and **Z₄, k = (0,1,1,1,1), genuine**. It is not in the centre lattice span{e_a, 2e_b, 2e_c, 2e_d, 2e_e}, and there is no massless U(1).
- **Physical proof (referee R2-11):** the SU(N)-invariant operator ac·bc·ab′ carries Z₄ charge 2.
- **K9 final:** STRUCTURAL OBSTRUCTION. The Yukawa matrices are block-diagonal 1 ⊕ 2 to all instanton orders. Generations 2 and 3 can come from instantons (S ≈ 5.6 / 11.8, estimate). Generation-1 mixing (and so V_us) needs extra Higgs fields or higher-dimensional operators with Z₄-charged vevs.

## D2121 (CENTRE): ping-pong loop closed. **NULL — BALANCED.**
- The negative-pole referee ran rounds R1, R2a–R2g.
- The positive pole applied the fixes D2119, D2120, D2120a and D2120b, with paper versions v2 → v6.
- The final referee round found nothing at major or blocker level.
- **Final paper:** papers/z2z6p_ps/z2z6p_ps.tex / .pdf (v6). Not published anywhere.
- **Final ledger:**
  - PASS: tadpoles, chiral spectrum, GS matrix (fixes the convention), K-theory, FI (literature mechanism), and chiral uniqueness in its class.
  - **K7 FAIL** (coupling matching, min ctrl 0.82).
  - **PS→SM OBSTRUCTED** perturbatively.
  - **ΔN_eff CONDITIONAL**.
  - **Z₄ texture 1⊕2** (conditional on a Z₄-neutral breaking sector).
  - The SU(2) threshold formulas in HRS need two corrections.

## D2122 (DEEP, ping-pong item 4): gauge anomalies. **PASS** (locked, run once).
- **Ping-pong:** the builder opened with what we have. The referee opened from the other end with R4-1 (GCS terms for Abelian anomalies), R4-2 (the dual-basis normalisation of the GS couplings) and R4-3 (Witten, generalised U(N)³, U(1)-grav²). All three were folded into the lock.

| Test | Result |
|---|---|
| T1: SU(4)³ | 0 |
| T2: generalised U(N_x)³, Π_x∘Σ N_a(Π_a + Π_a′) | 0 for all 5 stacks |
| T3: mixed U(1)_x–SU(N_y)², field theory (Table 28) = (N_x/2)(Π_x − Π_x′)∘Π_y | **all 25 entries match** |
| T4: GS factorisation | (Π_x − Π_x′) expands **exactly** in the HRS odd basis χ^{(k),α}. The coefficients equal the HRS c-matrix with **κ = 1** for all stacks and all 16 components, so HRS's GS couplings are independently confirmed |
| T5: U(1)–gravity² | 0 for all stacks, consistent with Π∘Π_O6 = 0 |
| T6: Witten SU(2) | doublet counts 24/24/16/4, all even |
| T7 (report only) | U(1)_x³ = 0 for all stacks. The mixed Abelian anomalies need generalised Chern–Simons terms (hep-th/0605225); not computed |

**Verdict:** checklist item 4 PASS.

## D2123 (DEEP, ping-pong item 9): robustness of the coupling-matching FAIL. **FAIL (robust).** Locked, run once.
Referee R9-1…R9-3 were folded in: 2-loop SM → MSSM running with y_t, DR-bar conversion, M_SUSY = 1 and 10 TeV, exotics at M_s/100, softer v bounds, and the reading dependence.

**Minimum ctrl by case:**

| Case | Min ctrl | Controlled? |
|---|---|---|
| R0 1-loop | 0.819 | no |
| R1 2-loop, 1 TeV | 0.800 | no |
| R2 2-loop, 10 TeV | 0.780 | no |
| R3 + exotics at M_s/100 | 0.811 | no |
| R4 v ≥ ½ | 0.800 | no |
| R5 v ≥ ¼ | 0.800 | no |
| R6 reading B (demoted) | 0.261 | yes |

- In every primary case, M_s ≈ 8e12 GeV.
- Relaxing the bound on v does not help: the minimum moves off the v₂ boundary and stays at 0.80.
- **The FAIL is robust** against running order, SUSY scale, intermediate exotics and the geometric bound. Only the disfavoured threshold reading (B) would pass. **The FAIL rests on the source paper's SU(2) threshold formula**, with the two-typo reading that makes it match the paper's own asymptote.

## D2124 (DEEP, ping-pong item 14): proton decay. **CONDITIONAL.** Locked, run once.

**T1: dim-5 superpotential operators.**
- Bose/Schur–Weyl symmetry leaves 6 flavour contents each for F_L⁴ (⊃ QQQL) and F̄_R⁴ (⊃ UDDE).
- **Z4 forbids 2 of the 6 in each** (F1F2²F3 and F1F2F3²). It **allows** F1²F2², F1²F3², F1²F2F3, and **F2²F3² (light generations only)**; likewise for R.
- The light-only structure carries ΔQ = (4,4,0,0,0) for F_L⁴, so it needs instantons with ΔQ_a = 4 (I = 1 on a) and ΔQ_b = 4 (I = 2 on b).

**T2: dim-6 Kähler operators F_L F_L F̄_R† F̄_R†.** 20 of the 36 flavour structures are Z4-allowed.

**T3: dim-4 RPV.**
- The PS trilinears 4·4·4̄ and 4·4̄·4̄ have no SU(4) singlet, so LLE, LQD and UDD are absent.
- **The Z2 = 2k acts as gauge matter parity:** charge 2 on all F and F̄, 0 on the Higgs. This is conditional on R-even vevs in the unknown breaking sector.

**T4 (ESTIMATE, M_s = 8e12 GeV):**

| Operator | Lifetime with O(1) coefficient | Required e^{−S} for τ ≥ 1e34 yr | Minimum S |
|---|---|---|---|
| dim-6 | 7e22 yr | ≲ 2.6e-6 | **≥ 12.9** |
| dim-5, gaugino-dressed, m_SUSY = 1 TeV | 2e5 yr | ≲ 4e-15 | **≥ 33** |

**Verdict:** CONDITIONAL. The Z4 does not protect the proton. The light-generation F2²F3² dim-5 operators are allowed and must be instanton-suppressed with S ≳ 33.
- That is much more suppression than the S ≈ 5.6–11.8 the Yukawas need. It is possible only because the two come from different instantons: Yukawa ΔQ = (0,2,∓2,0,0) vs proton ΔQ = (4,4,0,0,0).
- **The intermediate string scale makes proton decay a sharp test of the model.**

## D2124a (referee sweep of item 14, minors; recorded, not a verdict change)
- **Rates are conservative.** The T4 rates use m_p⁵ instead of the lattice matrix elements (α_H ≈ 0.012 GeV³, A_L ≈ 1.25; Nath & Fileviez Pérez, hep-ph/0601023). That overstates Γ by about 10⁴, so the S thresholds are **conservative ESTIMATEs**, too high by roughly ΔS ≈ 4.6. Corrected: S ≳ 28 (dim-5) and ≳ 8 (dim-6).
- **Channel.** The light F2²F3² structure is Q₁,₂-type, so the dominant channel is **p → K⁺ν̄** (Super-K τ > 5.9e33 yr).
- **Only light-only operators matter.** With the Z4 block structure, F1 does not mix with F2 and F3, so only F2²F3² and R2²R3² are relevant while the Z4 is exact.
- **Item 14: NULL — BALANCED.**

## D2125 (DEEP, ping-pong item 13): neutrino masses. **OBSTRUCTED; minimal seesaw FAIL.** Locked; one json-cast DEVIATION.
- **T1 (logic):** ν_Rν_R has Δ(B−L) = 2 with B−L ⊂ SU(4), so **M_R = 0 to all orders in unbroken PS**. Instantons respect non-Abelian symmetry, unlike the massive-U(1)_{B−L} case of hep-th/0609191. M_R needs the missing (4̄,1,2̄) breaking sector (K10).
- **T2 (computed):** with PS y_ν(M_s) = y_t(M_s) = 0.57–0.82 (2-loop, tan β-matched), m_D = 99–127 GeV. The **minimum m_ν = m_D²/M_s** (M_R ≤ M_s):

| M_s (GeV) | Minimum m_ν (eV) |
|---|---|
| 7.6e12 | 1.4–2.1 |
| 3.5e13 | 0.28–0.46 |
| 4.6e13 | 0.21–0.35 |

  **All 9 grid points exceed Σm_ν < 0.12 eV** (Planck + BAO). The 7.6e12 points also exceed KATRIN. So the **minimal type-I seesaw fails** for the perturbative generation.
- **T3:** a future Majorana texture depends on the unknown Z4 charge q_H of the breaking Higgs. For even q_H, M_R = 0 at all orders.
- **Escape routes** (each needs new structure): additional bidoublets or (15,2,2) Higgs fields to split m_D ≠ m_u, or an inverse/linear seesaw with singlets (possibly hidden states via the breaking sector).
- **Item 13 verdict:** OBSTRUCTED, plus FAIL of the minimal seesaw.

## D2125a (item 13 sweep): the FAIL is robust to running. Weinberg-operator running from M_R to M_Z changes κ by about 0.8–1.5, while a rescue would need about 0.3, since Σm_ν < 0.12 means m₃ ≲ 0.06 eV. Item 13: NULL — BALANCED.

## D2126 (DEEP, ping-pong item 18): dark matter and stable relics. **OBSTRUCTED** (stable fractional charges). Locked, run once.
- **T1:** we computed centre parities and electric charges (Y = T3R + (B−L)/2) for all states in Tables 28/29.
  - The states odd under the exact centre Z2(SU(2)_d) or Z2(SU(2)_e) are bd, bd′, be′, cd, cd′, ce′ (Q = ±½) and ad (coloured, Q = +1/6 and −½). **All carry fractional electric charge.**
  - The only neutral centre-odd state is the purely hidden **de′**, which is odd under both centres.
  - The lightest state in each odd class is absolutely stable (exact gauge centre plus charge conservation).
- **Why this is a problem:** the fractionally charged states are chiral under massive U(1)s only, so they are **massless at the perturbative level**, with no mass mechanism in the model. Light stable fractional charges are excluded (collider and terrestrial searches).
- **T2:** the condition for any fix is masses ≫ T_RH (unitarity, m ≲ 100 TeV for thermal relics, Griest–Kamionkowski), plus a mass mechanism (instanton or breaking-sector vevs).
- **T3:** the LSP is stable through gauge matter parity, conditional on R-even breaking. Thermal targets: higgsino ≈ 1.1 TeV, wino ≈ 2.7–3 TeV.
- **T4:** a PQ axion from a massive anomalous U(1) acting as a perturbative global symmetry (Honecker–Staessens 1312.4517) is possible. Misalignment requires θ ≈ 0.94 at f_a = 1e12 GeV and ≈ 0.28 at 8e12 GeV (ESTIMATE).
- **Verdict:** item 18 **OBSTRUCTED**. Stable, perturbatively massless, fractionally charged states (Q = ±½) are a generic hazard of hidden–visible bifundamentals. The only neutral candidates are de′, the LSP, and the axion.

## D2126a (item 18 sweep)
- **Stability is stronger than the centre argument.** The lightest fractionally charged particle is absolutely stable **by electric-charge conservation alone**. The centre classes can still allow decays to de′ plus an e-odd state.
- **Bound:** Perl, Lee & Loomba, Annu. Rev. Nucl. Part. Sci. 59 (2009) 47, doi:10.1146/annurev-nucl-121908-122035. Terrestrial abundance limits are about 1e-20 to 1e-22 per nucleon.
- **Item 18: NULL — BALANCED.**

## D2127 (DEEP, ping-pong item 20): independent reproduction. **PASS.** Locked.
- **The second implementation:** the referee wrote it from p.tex. Its exceptional table is parsed from the LaTeX, not hand-typed. It is archived at tools/seed/referee_blind/.
- **The builder-side diff:** **0 differences** in all 8 cycle vectors (Table 27 + 3 random branes) and in all random-brane χ entries. The blind code also reproduces bulk = 32, 24 twisted residuals = 0, and HRS Table 28 exactly.
- **Caveat:** it is independent in transcription and in code structure, but shares the documented readings (z₀, block-3, P2, cyclic X/Y).
- **R20-1:** the X/Y sum in p.tex (Σ_{i≠j≠k}) must be read over cyclic (i,j,k). The literal reading double-counts and fails bulk = 32. This goes in the paper.

## D2128 (DEEP, ping-pong item 6): independent derivation of the non-chiral spectrum. **PASS.** Locked; DEVIATIONS (1: target misread, 2: N=2 sign fixed by internal consistency).
- **Engine extended to per-sector level** with HRS formulas: the ω action (Eq. 1-cycle-orbits), the A-lattice orientifold image, the per-torus ℤ₂-invariant intersections from tab:Wilson_signs, and the β-coefficient multiplicity formulas.
- **P0 calibration:** the per-sector chiralities sum to the engine's orbit-level χ for **all 50 pairs** (x,y) and (x,y′).
- **Results:**
  - Every visible bifundamental has φ = |χ|.
  - **φ_bc = 1**: exactly one Higgs bidoublet. This confirms the single-bidoublet assumption behind the Yukawa, CKM and seesaw items.
  - **Adjoints:** d = 1 (Table 29's "4_Adj" is the U(2) adjoint, dimension 4); a, b, c, e = 0, i.e. rigid.
  - **φ_ad = 4**, i.e. 2×[(4,2̄_d) + h.c.]. This **settles R6-2**: Table 29 is right, and the HRS text's "one pair" undercounts (or means one pair of SU(2)_d doublets).
  - **φ_de′ = 2**.
  - **Bonus:** the xx′ sector totals computed with the same annulus formula give dd′ = 8 and ee′ = 4, matching Table 29's 4 sym + 4 anti and 2 + 2. That check does not need the conjectured Möbius sign.
- **N=2 rule adopted:** φ = ½δδ(|I^{(jk)}| + sgn(I^{(jk)}) f_j f_k), the only one of 7 conventions consistent in all 82 N=2 sectors.

## D2128a (correction to D2112 K5 and D2119 R1-10, from the 4_Adj misread)
- **b_{SU(2)_d} = 22, not 28** (one adjoint, not four). The other b's are unchanged: SU(4) −2, SU(2)_L,R +6, SU(2)_e +2. SU(2)_d is still IR-free, so no verdict changes.
- **ΔN_eff with 36 hidden chiral multiplets** (not 44):

| Case | ΔN_eff |
|---|---|
| vectors only | 0.11 (unchanged) |
| + fermions | **0.48** (was 0.56) |
| all massless | **0.77** (was 0.82) |

  The verdict stays **CONDITIONAL**.
- **D2128a numeric fix:** recomputed exactly, the ΔN_eff values are **0.50** (vectors + fermions) and **0.76** (all massless). The 0.48/0.77 written just above were rounding slips. The verdict is unchanged.
- **D2128 note (referee sweep):** the literal N=2 rule fails **4 sectors on φ ≥ |χ| and 6 on parity** (φ − |χ| odd), not "6 on φ < |χ|". The adopted rule passes both tests in all 82 sectors.
- It mirrors the three-angle formula (|I| + sgn(I)ΣI^{Z₂}). HRS's no-symmetric/antisymmetric condition (p.tex:1592, |I| − I^{Z₂} = 0 ⇔ 1 + 1/(q_j q_k) = 0) ties the sign of I^{Z₂} to the orientation, so this is a **notational resolution**, not a fudge.
- **Item 6: NULL — BALANCED.**

## D2129 (CENTRE): all 20 expert-checklist items settled. **Paper v7.1: NULL — BALANCED.**
- **How it was run:** the ping-pong protocol (papers/z2z6p_ps/review/PINGPONG_PROTOCOL.md), item by item: 4 → 9 → 14 → 13 → 18 → 20 → 6. Then a whole-paper sweep (R7-1…R7-7) and a confirmation sweep, which came back NULL.
- **Final tally:**
  - PASS (7): 1, 2, 3, 4, 5, 6, 20; plus 7 (U(1)s).
  - FAIL robust: 9.
  - TENSION: 10.
  - PARTIAL: 11.
  - OBSTRUCTED: 8, 12, 13, 18.
  - CONDITIONAL: 14, 17.
  - OPEN / not addressed: 15, 16, 19.
- **Status:** the paper is in the repo only. Publishing waits for Danny's "Publish".

## D2130 (CENTRE, ping-pong): the Weave UFE v4 built in ΛCDM parts, scored on compressed Planck 2018 (CHW, 4-parameter) + DESI DR2 BAO. **CONSISTENT.** Locked, run once.

**Card:** flat; N_eff = 3.044; Σm_ν = 0.0587 eV (3ν, normal ordering); n_s = 0.9706, α_s = −9.7e-4, r = 5.4e-4 fixed; DE = the exact reverse-thread w(a) (A = 7.30, β = 2√2) via PPF; ω_b and ω_c free (inputs); u_i free.

| Model | χ² (CMB + BAO) | Δχ² | ΔAIC vs ΛCDM |
|---|---|---|---|
| M1 ΛCDM (4 free) | 13.91 (2.61 + 11.30) | — | — |
| **M2 Weave (4 free)** | **13.93** (2.84 + 11.09) | +0.03 | **+0.03 → CONSISTENT** |
| M3 Weave a priori (u_i = 0.113 from full Planck+DESI+Pantheon+) | 13.96 | +0.06 | **−1.94** |
| M4 CPL proxy (−0.79, −0.36) | 17.66 | +3.75 | +1.75 |
| M5 ΛCDM with Weave n_s and Σm_ν | 13.94 | +0.03 | −1.97 |
| M6 w0waCDM (6 free) | 6.81 | −7.09 | −3.09 |

- **Derived (M2):** H0 = 68.49, Ω_m = 0.303, r_d = 147.20 Mpc.
- **n_s:** the fixed n_s = 0.9706 costs nothing (+1.3σ raw against the CHW n_s, absorbed through the correlations).

**Readings:**
1. With CMB + BAO alone, the thread's best fit sits near Λ (fitted w0 ≈ −0.99, wa ≈ −0.01; w ≥ −1 everywhere). It cannot reach the DESI w0wa region (M6, Δχ² −7.1). As expected for thawing quintessence, the Weave matches ΛCDM here but **does not capture the DESI dynamical-DE preference** without SN.
2. **The card's (w0, wa) ≈ (−0.79, −0.36) is NOT what the thread gives on these data.** That CPL proxy also fits worse (M4, +3.75) and is phantom at high z (RW-1). The card value should be withdrawn as a summary of the thread.
3. **Untestable here:** r, α_s, A_s, τ, lensing, birefringence.

**Next:** the SN extension (Pantheon+/DES-Y5) needs Danny's download OK. A full-Planck rerun with the Weave-fixed n_s needs the Planck likelihood data (PC, or a cloud download with OK).

## D2130a (referee sweep: RL-1, RL-2). D2130 is now NULL — BALANCED.
- **RL-1, M3 is not a priori.** u_i = 0.113 came from the earlier full Planck+DESI+Pantheon+ *fit*, so M3 is "u_i fixed to the earlier full-data fit", not a priori. Even there the thread gives (w0, wa) ≈ (−0.97, −0.04). So the card's (−0.79, −0.36) comes from neither fit and is **withdrawn**. In the SN extension u_i must stay free, or the test is circular.
- **RL-2, where the ΔAIC ≈ −1.9 comes from.** It is the bookkeeping gain of fixing n_s and Σm_ν (M5 also gives −1.97). The dark-energy sector contributes Δχ² ≈ 0. **The headline is M2: CONSISTENT (ΔAIC +0.03).**

## D2131 (CENTRE, ping-pong): the Weave in ΛCDM parts on Planck plik-lite (+ τ prior) + DESI DR2 + SN. Locked, run once. **Pending referee sweep.**

| SN set | W − L Δχ²_eff (same k) | Verdict W vs L | Thread CPL (w0, wa) | C − L Δχ² (ΔAIC) | W vs C ΔAIC |
|---|---|---|---|---|---|
| Pantheon+ | +0.13 | **CONSISTENT** | (−1.00, 0.00), u_i = 0.013 | −6.2 (−2.2) | +2.4 |
| **DES-Y5** | **−10.1** | **PREFERRED** | (−0.89, −0.18), u_i = 0.173 | −19.2 (−15.2) | +5.1 |
| Union3 | −0.46 | **CONSISTENT** | (−0.97, −0.04) | −13.1 (−9.1) | **+8.6** |

**Readings:**
- The Weave never does worse than ΛCDM, and on DES-Y5 it is clearly better.
- **It falls short of free w0wa everywhere.** On Union3 that is decisively so (ΔAIC +8.6): w0wa prefers wa ≈ −0.63, while a thawing field with w ≥ −1 stays near Λ.
- Pinning n_s = 0.9706 costs nothing: L finds n_s 0.969–0.970.
- **Limitations:** no low-ℓ TT and no lensing; the τ prior stands in for low-ℓ EE.

## D2133 (CENTRE, referee pole's own locked test, archived at field_tests/weave_lcdm/referee_indep/): independent thread plus a Dovekie fit.
- **T1:** the referee re-derived the thread from the potential alone, without seeing our code. **It agrees with rt_wtable to ≤ 8e-6 in w(a)** at u_i = 0.013, 0.109 and 0.173.
  - Both codes find **no flat solution for u_i ≳ 0.22**: V goes negative before today and the universe collapses. That is a physical upper edge on the thread.
- **T2** (compressed CHW + DESI DR2 with full covariance + **DES-Dovekie**, 1820 SNe, analytic M marginalisation):
  - ΛCDM χ² = 1648.23. Weave profile minimum at u_i ≈ 0.157 (**single minimum**), giving **Δχ²(W − L) = −4.24**: CMB +1.57, BAO −1.37, SN −4.44.
  - **The Dovekie recalibration removes about 60% of the DES-Y5 gain** (−10.1 → −4.2).
  - Builder review of fit.py: correct (the Dovekie inverse covariance unpacked as in Cobaya, d_L = (1 + z_hel)D_M(z_HD), analytic M, BAO keys from the shipped file). One minor point: the w-table cache rounds Ω_m to 3 decimals, a negligible coarsening.
- **This predicts "SN-calibration dependent"** under the D2132 −6 rule. D2132's full PR4 number decides.

## D2132 setup notes from the referee (RD-1…RD-4; recorded before any D2132 output)
- **RD-1:** check that χ²_eff misses no info-level Gaussian priors (verify upd['prior']).
- **RD-2:** the u_i prior runs to 0.6 and the ref to 0.3, past the ~0.22 collapse edge, so some BOBYQA starts may hit −∞. Any stall must be recorded.
- **RD-3:** the likelihood set is the standard PR4 combination (null).
- **RD-4:** the docstring is stale (cosmetic).

## D2134 (CENTRE, knob board, locked PREREG_D2134 + addendum + DEVIATION 2). Thread–DM coupling b scanned on compressed CMB + DESI DR2 + SN. **Verdict: NOT ADOPTED. The knob does not earn its place.** (2026-11-22 ~19:10 CT)
- **Gate G0 PASS:** the own late-time solver matches CAMB to a max relative deviation of 8.3e-5.
- **Results** (Δχ² relative to the ΛCDM reference; ω_b, ω_c, V̂_L and u_i re-fit at each b):

| b | Dovekie | Pantheon+ | Ω_φ(z*) | Δφ_total | DM mass change |
|---|---|---|---|---|---|
| −0.05 | +10.3 | +9.2 | 5.5e-4 (r_s guard: not adoptable) | +0.62 | −3.1% |
| −0.025 | −2.1 | −1.8 | 1.3e-4 | +0.22 | −0.5% |
| **0** (Weave) | **−4.5** | **−2.8** | 1e-9 | −0.19 | 0 |
| +0.025 | −6.6 | −4.8 | 1.3e-4 | −0.50 | −1.3% |
| +0.05 | −4.1 | −1.6 | 5.4e-4 (not adoptable) | −0.84 | −4.1% |
| ±0.075 … ±0.15 | worse, or solver failure at +0.1 | | | | |

- **Adoption test** (best adoptable b = +0.025, relative to b = 0): Dovekie −2.1 and Pantheon+ −2.0. Both miss the locked Δχ² ≤ −4, so the 2-of-3 rule cannot pass whatever Union3 gives. **NOT ADOPTED.**
- **Union3 run crashed in the data loader** (a column-count mismatch on the Union3 file). No numbers came out. A fix would need a DEVIATION, but it cannot change the verdict.
- **S₈ proxy:** 0.857 at b = 0 and 0.851 at +0.025. The Weave baseline is already above the locked 0.83 ceiling in this proxy, and b < 0 lowers it (0.80 at −0.05) but costs χ². Stated honestly: **S₈ is a weak spot of the Weave baseline, not something the knob fixes.**
- **α leak:** ≤ 7.5e-10 at every b, even |b| = 0.15. The α-drift is untouched, as the referee confirmed (F-2).
- **Sign-convention correction (addendum item 1 was wrong):** the DM mass FALLS for both signs of b. The coupling force −bρ_c pushes φ so that bΔφ < 0 (Δφ = +0.62 at b = −0.05 and −0.84 at b = +0.05). So "b < 0 means DM gains mass" is false here. The addendum's text is superseded by this note, not edited.
- **The bookkeeping lesson:** the Weave's late-time gain lives at b = 0, and coupling dark matter to the thread buys at most about 2 more units of χ². The scored results (D2131–D2133) stand unchanged.

## D2134a (CENTRE, referee pass on D2134: verdict **BALANCED**, NOT ADOPTED confirmed). Corrections to D2134, each a dated note; D2134 itself is not edited (2026-11-22 ~19:25 CT)
1. **Sign.** The coupling drives φ down V + ρ_c(φ), so the DM mass falls for both signs of b. The referee agrees, and its own K-mapping was the source of addendum item 1's wrong sign.
2. **Bounds and crashes.**
   - At b = −0.025, u_i sits at the 0.21 bound on both sets (the χ² there is a constrained value).
   - At b = −0.15, H0 is at its bound (80).
   - b = +0.10 is a **crash** ("cannot unpack non-iterable float"), not an excluded value.
   - The adoptable rows (|b| ≤ 0.025) are clean. u_i falls as b rises (0.157 → 0.068 → 0.031): the coupling takes over the thawing.
   - The dial `dm_loss_since_zstar` actually measures the total since a = 1e-6, so it is mislabelled.
3. **S₈ proxy: D2134's "weak spot" line is WITHDRAWN.**
   - The proxy's absolute level is not calibrated, because A_s is not fitted.
   - The 0.83 cut would reject Planck ΛCDM itself, which sits at about 0.832.
   - On differences, the coupling slightly LOWERS S₈ (0.856 → 0.851 → 0.842 for b = 0 → 0.025 → 0.05).
   - A future lock should cut on ΔS₈ relative to LCDM_ref, at ≤ +0.02.
4. **Robustness.**
   - A parabola through the b = 0, +0.025 and +0.05 rows bottoms out at b ≈ 0.023 with Δχ² ≈ −2.1, so no b reaches −4.
   - The verdict does not depend on Union3.
5. **Triangulation.** At b = 0 on Dovekie, my fit gives u_i = 0.157 and Δχ² = −4.47; the referee's independent D2133 gives 0.157 and −4.24. **They agree.**
6. **Caveat: Pantheon+ at b = 0 depends on the CMB treatment.**
   - With compressed CMB: u_i = 0.148, Δχ² = −2.8.
   - With plik-lite (D2131): u_i = 0.013, Δχ² = +0.13.
7. **Not claimed: the DESI pull on w0wa.** At b = +0.025 the CPL fit is (−0.92, −0.07), far from DESI's (−0.75, −0.8). The apparent crossing depends on which anchor is used.

## D2136 (CENTRE, the 10th layer: resonance pulsing plus breathing, three shapes; lock PREREG_D2136 + addendum R36-1…4 + DEV-1). **Verdict: DOES NOT SOLVE the Hubble tension. The outer shell wants ΔN_eff ≈ 0.6, and the negative-space shell forbids it.** (2026-11-22 ~19:40 CT)
- **Method:** tools/loom/resonance10.py. Results in field_tests/results/d2136_resonance10_{V0,VA,VB,VC}.json. Deterministic consistency map, not evidence (D1948).
- **Baseline H0 = 67.43,** the median of three newest-data b = 0 fits. s = 6.2 [E].

| run | locked layers | ΔN_eff | H0 | SH0ES margin (pull) | what it means |
|---|---|---|---|---|---|
| V0 (9 layers) | 1, 2, 5, 6, 7, 8 | 0 | 67.43 | — (5.4σ) | base unchanged (3, 4, 9 TRUST, as D1972) |
| VA (+ outer data shell) | + **10** | **0.60** | 71.15 | +0.18 (1.8σ) | the shell locks only by spending dark radiation that ACT forbids |
| VB (+ negative-space shell) | 1, 2, 5, 6, 7, 8 | 0.395 | 69.88 | −1.04 (3.0σ) | **NO LOCK**: the optimizer splits the failure evenly between SH0ES and the ACT bound (both −1.04) |
| VC (+ spine) | same as VB | 0.395 | 69.88 | −1.04 | the spine adds nothing: the BBN bound never binds (as R36-2 said) |

- **Breathing:**
  - Inhale and exhale both give the same result, and no inner layer unlocked in any breath, so the inner field stays balanced.
  - The new rung simply cannot lock with the negative-space shell in place.
- **Pinned at the ACT bound** (ΔN_eff = 0.14): H0 = 68.30, a pull of 4.6σ. That is a drop of only 0.8σ, below the 1σ "eases" bar. **Not eased.**
- **Fluid reading** (self-interacting dark radiation, the PS type; WZDR from 2512.19633): H0 = 68.75, margin −1.09 (3.1σ). **Not solved.**
- **CCHP second reading** (69.96 ± 1.53): the baseline is already only **1.7σ** away, so it passes (margin +0.35 at ΔN_eff = 0). Whether "the tension" exists depends on which distance ladder is used. Against SH0ES it does not close.
- **PS window side test** (0.11 ≤ ΔN_eff < 0.14): it exists only for the vectors-only case. It is closed once the hidden fermions are included (0.50) or all massless states (0.76).
- **Reading in Danny's picture:** the outer ring (shape A) reaches for SH0ES. The second ring wrapped around it (shape B, negative space: ACT's "no extra radiation") holds it back, and the two meet halfway, both failing by the same amount. **The negative space is exactly what blocks the extra rung.** A Weave route to 73 needs a lever that ACT's negative space does not see. The referee's audit found none within the Weave: u_i and b move H0 the wrong way or too little, α and m_e are ≈ 0, and curvature is 0.

## D2136a (CENTRE, referee pass on D2136: **BALANCED**; "does not solve" confirmed and every number recomputed). Wording corrections; D2136 itself is not edited (2026-11-22 ~19:45 CT)
- **The "meet halfway" reading is withdrawn.** Both shells reading −1.04 is an artifact of units: a pull margin is being balanced against a log margin. The plain statement is this. Reaching SH0ES at 2σ needs ΔN_eff ≈ 0.51, which is 3.6× the ACT bound (margin −1.29) and also above the BBN bound of 0.3.
- **Both non-solutions are optimistic, so the verdict is conservative.**
  - The linear FS map ignores the CMB χ² rise along the degeneracy, so 68.30 at the ACT bound is an upper estimate.
  - The fluid reading is a ΛCDM+WZDR fit, so it is only a **proxy** for the Weave with fixed n_s plus the thread.

## D2137 (MAP ONLY, not derived; Danny 19:17 "map it, but we don't need to derive it… pulse that way and start connecting it"): the negative-space ladder, one mirror node under each of the 10 layers, plus the first node beyond the shell
- **Tool:** tools/loom/negspace_ladder.py, with results in field_tests/results/d2137_negspace_map.json.
- **What each node holds:** what its layer forbids us to see, the Weave's log headroom under today's bound (from the record; nothing new derived), and the number that connects it to its layer.

| node | mirrors | forbidden (no-show) | headroom |
|---|---|---|---|
| N1 | torus | extra light rung states | OPEN |
| N2 | pyramid (ν at i) | Σm_ν < 0.064; m_ββ < 28 meV | +0.09; +2.0 |
| N3 | turnover (leptons) | Koide slip ≤ 6e-5; lepton-flavour violation | TRUST / OPEN |
| N4 | cube | domain walls; light moduli | TRUST / OPEN |
| N5 | fold (m3/2) | sparticles below ~0.2 PeV; gravitino τ < 0.1 s | +4.3 (wino vs LHC still owed) |
| N6 | dilaton | r < 0.036; isocurvature; f_NL | +4.2 |
| N7 | forces | proton decay (Super-K); θ̄; EDMs; X17 | +1.9 |
| N8 | cosmology | ΔN_eff < 0.14 | TRUST (0 exactly) |
| N9 | thread | phantom crossing; α drift; b; equivalence principle | +6.9 (α) |
| N10 | outer shell | the D2136 B shell | −1.04 when forced to SH0ES |
| **N11** | **first node beyond** | string-theory negative space: TCC wants r ≲ 1e-30 (Weave 5.4e-4: **flag**, not veto); no controlled de Sitter (Λ is an input); axion WGC; distance conjecture | FLAG / TRUST |

- **Joints (shared numbers) found by the pulse**, running outer → inner, then beyond:
  - **N6 ↔ N11 through r.** The same r that passes the CMB bound by e^4.2 is what the TCC forbids.
  - **N8 ↔ N10 through ΔN_eff.** This is the D2136 spine.
  - **N2 ↔ L2 through Σm_ν**, which is tight at +0.09: DESI is closing in.
  - **N5 ↔ N9: no joint yet.** m3/2 does not reach the thread. This is open.
- **Weakest nodes:** N2's Σm_ν (+0.09) is the closest negative-space wall, then N10. The OPEN nodes (N1, N3's LFV rate, N4's τ_q decay temperature) are where the Weave owes a number. **Map only:** none of these is derived. They are queued, not claimed.

## D2138 (MAP ONLY, not derived; Danny 19:19 "start mapping the other way in the negative space… pulse that way… see how many nodes"): the outward pulse from N11
- **Tool:** tools/loom/negspace_outward.py, with results in field_tests/results/d2138_negspace_outward.json.
- **Rule (fixed in the tool's docstring):** a ring becomes a node only if it brings a new class of forbidden thing **and** a number or joint that touches the Weave. Stop at the first ring with neither (NULL).
- **Count:** 5 new nodes beyond N11 (N12–N16). N17 is NULL, so N1–N16 make **16 negative-space nodes in all**.

| node | ring | Weave reading | joint |
|---|---|---|---|
| N12 | quantum-gravity consistency | H_inf = 5.8e12 GeV, which leaves room for N < 1.8e11 light species; the residual Z₃ sits inside SL(2,Z), which is gauged (PASS, literature) | the species plateau → L6; Z₃ → L3/L4 |
| N13 | de Sitter / far future | no eternal dS, because the thread rolls toward i (structural PASS); thread slope \|V′\|/V = 0.53 at the start, less today, so the refined-dS c ~ O(1) is **MARGINAL** | u_i → L9 |
| N14 | before the beginning | E10 billiard OPEN; the dimension at horizon exit comes from r | r → L6 |
| N15 | vacuum selection | ρ minimises every lattice sum (Montgomery 1988): **PASS** without anthropics | ρ → L1, the centre |
| N16 | consistency of the fold | anomalies and K-theory PASS (IIA PS seed); the IIB \|M\| = 9 flux tadpole **FAILS** the tadpole conjecture. The two models differ, which is labelled, not merged | \|M\| = 9 → L5/L7 |
| N17 | logic / axioms | no number, no joint | **NULL** (the pulse stops here) |

- **What the pulse connected:**
  - **r is the most-used joint.** It appears at N6, N11 and N14: the CMB passes it, the TCC flags it, and it sets the pre-inflation dimension.
  - **The outer negative space bends back to the centre:** N15 (vacuum selection) lands on L1's knot ρ.
  - **The two live outer walls are N13's dS slope (marginal) and N16's tadpole (FAIL).** These are the outer-space mirrors of the inner FAILs (α_s, Δ₃).

## D2139 (CENTRE, derived: lock PREREG_D2139). Three negative-space nodes computed; three more scoped as projects (2026-11-22 ~19:50 CT, referee review pending)

| node | what was derived | result | verdict |
|---|---|---|---|
| **N13** refined de Sitter | thread slope \|V′\|/V = βu/(1−u) along the fitted D2134 b = 0 Dovekie thread | 0.53 at the start (u_i = 0.157) → **1.06 today** (u₀ = 0.272) | **PASS** against c ≥ √(2/3) = 0.816, the TCC/asymptotic form |
| **N4** light moduli | τ_q decay temperature at m = 2e10 GeV, Γ = m³/(4πM_P²), O(1) and 1/8π couplings | T_d = 5.5e4 – 2.8e5 GeV | **PASS** (≫ 5 MeV) |
| **N3** lepton-flavour violation | μ→eγ by mass insertion at m_s = 0.25 PeV, tan β = 4, δ₁₂ = 1 [E] | BR = 3.7e-17 | **PASS** (MEG II limit 1.5e-13; any δ₁₂ ≤ 64 is allowed) |

- **Correction to D2138's N13 line.** It said the slope is "smaller today". That is wrong. The thread thaws (φ falls), so u grows and the slope rises from 0.53 to 1.06. N13 moves from MARGINAL to **PASS** today. The early-time slope of 0.53 applies only while dark energy is negligible.
- **Not derivable tonight; scoped as projects:**
  - **N1:** hidden-family masses on the empty rungs. Needs the rung-spectrum project.
  - **N14:** the pre-inflation E10 billiard. A research programme.
  - **N16:** the tadpole. Needs the B2 rebuild (families from intersections in IIB). The PS seed shows that such charge closure is possible.
- **Negative-space scoreboard (N1–N16):**
  - PASS: N2, N3, N4, N5, N6, N7, N9, N12, N13, N15
  - TRUST: N8
  - FLAG: N11 (TCC on r)
  - FAIL: N10 (the H0 shell) and N16 (tadpole)
  - OPEN: N1, N14

## D2139a (CENTRE, referee pass on D2139: NOT BALANCED on R39-1, now restated). Corrections; D2139 itself is not edited (2026-11-22 ~19:55 CT)
- **R39-1, N13: the lock's bar was mis-specified.** The swampland conditions apply at every field point the thread visits, not only today. Restated as three branches, each recomputed in code:

| branch | path value | bar | verdict |
|---|---|---|---|
| slope \|V′\|/V | 0.53 at the start → 1.06 today; the path minimum is 0.53 | ≥ 0.816 | **FAIL** on the past part of the path, **MARGINAL** against c ≥ 0.5 |
| second derivative V″/V = −8u/(1−u) | −1.49 at the start → −2.99 today | ≤ −c′, c′ ~ O(1) | **PASS** everywhere visited (c′ up to 1.49) |
| asymptotic / TCC | as φ → ∞, u → 0 and V → V_L > 0, a dS plateau | — | the known limitation, the same plateau as inflation's A = 7.30 (N11 FLAG) |

  The refined conjecture (OPSV) needs only one of the two branches, so **N13 passes the refined conjecture through its second-derivative branch.** It does not pass the TCC/asymptotic form. D2139's "PASS (slope today)" is withdrawn.
- **R39-2, N4: relabelled "PASS (BBN only)".**
  - The second reading was mislabelled. With a true 1/(8π)² coupling, T_d = 1.1e4 GeV, which still passes.
  - **New open nodes:**
    - (a) τ_q entropy dilution of η_B and of the asymmetric DM;
    - (b) moduli-induced gravitino production if m3/2 < m/2;
    - (c) whether the same decay is what makes the non-thermal wino density (Ωh² ≈ 0.02).
- **R39-3, N3: PASS for any δ₁₂ ≤ 1.** The phrase "δ ≤ 64" is withdrawn, since δ ≤ 1. μ→e conversion (~1e-19) is also below Mu2e/COMET reach.
- **New node, the electron EDM [E]:** d_e ~ e m_e (α/4π) sinφ / m_s² = 9.4e-32 e·cm at 0.25 PeV with O(1) phases. The JILA 2023 limit is 4.1e-30, so it **PASSES with a margin of about 44**, the thinnest of the flavour/CP walls.
- **Negative-space scoreboard, updated:**
  - PASS: N2, N3, N4 (BBN only), N5, N6, N7 (with the eEDM inside), N9, N12, N13 (second-derivative branch), N15
  - TRUST: N8
  - FLAG: N11
  - FAIL: N10 (H0) and N16 (tadpole)
  - OPEN: N1, N14, and N4's moduli-cosmology items (a)–(c)
- **Referee verdict after this restatement:** the conditions R39-1…3 are all folded in.

## D2141 (RIGHT, data check, class D: not blind; the number was read before this note). The wino against the newest LHC disappearing-track limit. **ALIVE, at the edge.**
- **Source:** ATLAS, 2603.08315 (137 fb⁻¹, 13 TeV), long-lived charginos with a disappearing track. On the pure-wino mass-splitting line (~160 MeV), charginos are **excluded up to 670 GeV observed (770 GeV expected)**. For ~1 ns lifetimes the reach is 880 GeV (1020 expected). This is a single source; the rule asks for three, so a CMS cross-check is owed.
- **Weave:** m_w = m3/2/375 = 2.6e5/375 = **693 GeV** (central), window 0.67–1.0 TeV [R].
- **Reading:**
  - The central value is **23 GeV above the observed limit**, but below the expected reach (770). The observed limit is weaker than expected, a fluctuation in the data that is **not claimable** as a hint.
  - The low end of the window (0.67 TeV) now coincides with the observed exclusion.
  - The HL-LHC projection (~0.98 TeV, record) covers almost the whole window, so this is a **live falsification test**.
- **Verdict:** **PASS (barely)**, and the window starts at 0.67 TeV. Recorded as the sharpest near-term collider test of the Weave.

## D2142 (RIGHT, status only). The 12.8 GeV asymmetric DM against LZ
- The record already used the LZ ceiling to bound the dark-photon mixing (D1688). So the direct-detection rate is **accommodated (a bound sets a knob), not predicted**. No independent test exists until the mixing is derived.
- **Label:** NO-POWER (cannot fail today). An honest line for the big-questions board.

## D2140 (CENTRE, derived: lock PREREG_D2140). τ_q moduli cosmology, negative-space node N4(a)–(c). Referee review pending
- **(a) Dilution D = T_R φ0²/(6T_d):** 808 at m = 2e10 GeV and 72 at 1e11. Both are ≤ 1e3, so **PASS**.
- **(b) Moduli-induced gravitinos → winos:** T_3/2 = 23 MeV.
  - With the generic Br = 0.01–0.1, re-annihilation caps the wino density at **Ωh² = 3–37**, which overproduces by ×100–1000.
  - Only the suppressed Br ≈ (m3/2/m)² ≈ 1.7e-10 passes (Ωh² ≈ 7e-4). That requires τ_q to be supersymmetrically stabilised and sequestered.
  - Alternatively φ0 ≲ 3e-5 M_P passes, but then there is no dilution and r takes the 5.4e-4 branch rather than 5.72e-4.
  - **Verdict: CONDITIONAL.** This is a new, real constraint, and it joins the quark modulus to the CMB value of r.
- **(c)** In the case that passes, τ_q makes a negligible share of the winos, so the wino share stays thermal-gravitino (D1687).

## D2140a (CENTRE, referee pass on D2140: NOT BALANCED on R40-1, now restated). Corrections; D2140 itself is not edited (2026-11-22 ~20:10 CT)
- **R40-1, (b) relabelled: generic FAIL.**
  - The lock wrongly called Br ≈ (m3/2/m)² "the supersymmetrically stabilised case". For a supersymmetrically stabilised modulus, G_φ ~ m3/2/m, and the goldstino's 1/m3/2² enhancement cancels that suppression. So Br(τ_q → 2ψ) ~ 1e-2 to 1e-1, **unsuppressed** (Endo–Hamaguchi–Takahashi hep-ph/0602061; Nakamura–Yamaguchi hep-ph/0602081).
  - **Verdict for (b): FAIL generically.** The winos are overproduced ×86 even at the most generous σv.
  - **Two named conditional escapes, both now OPEN nodes:**
    1. **N4-seq:** τ_q sequestered from the SUSY-breaking sector, with G_τq ≪ m3/2/m (Dine–Kitano–Morisse–Shirman-type conditions, hep-ph/0604140). The Weave has not shown this.
    2. **N4-φ0:** τ_q starts with φ0 ≲ 3e-5 M_P. The cost is no dilution, and r moves to the 5.4e-4 branch.
- **R40-2 and R40-3: confirmed.**
  - The re-annihilation cap was recomputed by hand: T_3/2 = 22.9 MeV, g* = 10.75, Ωh² = 9.2 at σv = 1e-24.
  - The min(1, D) factor is correct.
- **R40-4, added:**
  - Direct τ_q → gaugino decays at T_d ≈ 2.8e5 GeV re-thermalise and are harmless.
  - D = 808 also dilutes the thermal gravitinos from T_R, which helps. It preserves the asymmetric-DM-to-η_B ratio, and leptogenesis needs ×800 room, which is within 1e3.
  - Gravitino decays at 1.4 ms pass BBN.
  - **(c) is now conditional** on the same escape.
- **Consequence for the negative-space board:** N4 = **FAIL (generic)**, with two open escapes. This is a real new weak spot, joining N10 (H0) and N16 (tadpole).
- **Two hubs now tie to it:**
  - **N4-φ0 ↔ r:** the CMB measurement of r would decide between the branches (5.4e-4 vs 5.7e-4; this needs σ_r ≲ 1e-5, so it is not testable soon).
  - **N4-seq ↔ N16:** sequestering is exactly what a B2 rebuild of the fold would have to supply.

## D2143 (CENTRE, sensitivity map: lock PREREG_D2143 + DEV-1). Danny's "wall here, pull each node both ways, look for a thrust". **A one-way clock shift from a two-way pull IS seen at three nodes, strongest at the thread–DM coupling b.** (2026-11-22 ~20:25 CT, referee review pending)
- **Clocks:** the early clock is N\* (e-folds at horizon exit; base 68.0). The late clock is the age t₀ (base 13.715 Gyr at H0 = 67.43), from the calibrated engine.
- **Definitions:** response = (Δ₊ − Δ₋)/2; thrust = (Δ₊ + Δ₋)/2, the net drift under a symmetric pull.

| node (pulled ×1.5 and ÷1.5, or ±) | clock | Δ₊ / Δ₋ | response | thrust | reading |
|---|---|---|---|---|---|
| N4 τ_q dilution D | N\* | −0.135 / +0.135 | −0.135 | 0 | ties through time, linear (ln D): no thrust |
| N8 reheating T_R | N\* | +0.135 / −0.135 | +0.135 | 0 | ties through time, linear: no thrust. **N4 and N8 are mirror images: pulling the wall cancels pulling the centre** |
| N6 r (CMB wall) | N\* | −12.5 / +15.3 | −13.9 | **+1.4** | strong tie, curved (r ∝ N\*⁻²): thrust toward longer inflation. This is the algebra of the plateau, not new physics |
| N9/N13 thread start u_i | t₀ | +0.254 / −0.191 Gyr | +0.222 | **+0.031 Gyr** | ties through time; the thawing curve is bent, so a symmetric pull leaves the universe 31 Myr older |
| **N9 coupling b (best fits)** | t₀ | **−0.021 / −0.033 Gyr** | +0.006 | **−0.027 Gyr** | **both directions make the universe younger.** A two-way pull gives a one-way drift. The cause is D2134a: DM loses mass for either sign of b, so the pull always runs the same way. This is the clearest case of Danny's "thrust" |
| N10 H0 shell (V_L) | t₀ | −0.855 / +0.777 Gyr | −0.816 | −0.039 | the strongest time tie, nearly linear (5%, below the 10% bar) |
| N8/N10 ΔN_eff (late clock only) | t₀ | ≈ 0 | — | — | no late-time tie (its effect is on the early sound horizon) |
| N1, N2, N3, N5, N7, N11, N12, N14, N15, N16 | — | — | — | — | tie through mass or charge, not time |

- **What this says about the postulate:**
  - Six of the 16 nodes tie through the cosmic clock. Ten tie through mass or charge only, so the postulate is **partly** right.
  - Where the wall is curved, a symmetric pull gives a net clock drift ("thrust"): N6, u_i and, most cleanly, b.
- **Honest bound:** this "thrust" is a re-timing of cosmic history (the universe's age, or when inflation's scales left the horizon). It is **not** motion through time. Nothing in the equations permits that.

## D2143a (CENTRE, referee pass on D2143: NOT BALANCED on R43-1/2, now fixed via DEV-2). D2143 itself is not edited (2026-11-22 ~20:40 CT)
- **Up front:** these numbers re-time cosmic history (the universe's age, inflation's horizon-exit time). They are not motion through time. A non-zero "even response" appears at ANY extremum of ANY smooth function, so **it cannot validate the postulate**. The words "thrust", "clearest case of Danny's effect" and "postulate partly right" are **withdrawn**.
- **Common protocol (DEV-2).** ω_b and ω_c are held at the b = 0 fit, and V_L is re-solved so the CMB scale ℓ_A is unchanged. The first run held V_L fixed instead, so the u_i row was not anchored either.
  - **u_i ×/÷1.5, anchored:** +28.6 / −10.6 Myr. Response +19.6 Myr, even part +9.0 Myr. That is roughly 10× smaller than the unanchored numbers, which were mostly an H0 shift.
  - **b, anchored:** b = −0.025 gives −50 Myr. At b = +0.025 the solver collapses at u_i = 0.157 (no number), so no symmetric pull exists for b under this protocol.
  - **Data-constrained best-fit ages** (each b refitted, not a pull): 13.683 / 13.715 / 13.694 Gyr for b = −0.025 / 0 / +0.025. The −21 to −33 Myr differences are comparable to the age's own uncertainty (tens of Myr), so they are **not significant**.
- **N4/N8:** equal and opposite **by construction** (both enter as ⅓ ln). This is not a finding.
- **What survives:** six of the 16 negative-space nodes have a numeric tie to a cosmic clock (N4, N6, N8, N9/N13, N10, ΔN_eff weakly). The other ten tie through mass or charge. That is a map of couplings, nothing more.

## D2144 (CENTRE, derivation table: lock PREREG_D2144). Each negative-space node's equation at the wall, then pulled inward (÷1.5) and outward (×1.5). Margins are log headroom; ✔ means the wall holds (2026-11-22 ~20:50 CT, referee review pending)

| node | equation | knob | in / wall / out | holds in / wall / out |
|---|---|---|---|---|
| N2 ν mass | Σm_ν from the splittings [S], DESI < 0.064 | Σm_ν | 0.039 / 0.0587 / 0.088 eV | ✔ / ✔ (+0.09) / **✘** |
| N3 μ→eγ | α³π δ² tan²β/(G_F² m_s⁴) [E] | m_s | 1.9e-16 / 3.7e-17 / 7.3e-18 | ✔ / ✔ / ✔ |
| N4a dilution | D = T_R φ0²/(6T_d), T_d ∝ m^{3/2} [R+S] | m_τq | 1480 / 808 / 440 | **✘** / ✔ / ✔ |
| N4b moduli gravitinos | 2.744e8 m_w min(Y_3/2, Y_cap) [S] | Br | 9.2 / 9.2 / 9.2 (capped by re-annihilation) | ✘ / ✘ / ✘. **Pulling the knob cannot fix it**; only N4-seq or N4-φ0 can |
| N5 gravitino lifetime | τ ∝ m3/2⁻³ [S] | m3/2 | 4.7e-3 / 1.4e-3 / 4.2e-4 s | ✔ / ✔ / ✔ |
| N5w wino vs LHC | m3/2/375 [R] | m3/2 | 462 / 693 / 1040 GeV | **✘** / ✔ (+0.03) / ✔ |
| N6 r | r = r0(68/N\*)² [S] | N\* | 1.2e-3 / 5.4e-4 / 2.4e-4 | ✔ / ✔ / ✔ |
| N7 proton | τ_p ∝ M_X⁴ [S] | M_X | 3.2e34 / 1.6e35 / 8.1e35 yr | ✔ (+0.28) / ✔ / ✔ |
| N7e electron EDM | e m_e (α/4π) sinφ/m_s² [E] | m_s | 2.1e-31 / 9.4e-32 / 4.2e-32 | ✔ / ✔ / ✔ |
| N8 reheating clock | ΔN\* = ⅓ ln(T_R/T_R0) [R] | T_R | −0.135 / 0 / +0.135 | clock tie only |
| N9 α leak | ζ_α\|Δφ\| [R] | ζ_α | 4.9e-11 / 7.3e-11 / 1.1e-10 | ✔ / ✔ / ✔ |
| N12 species room | (M_P/H)², H = π√(A_s r/2) M_P [S] | r | 2.7e11 / 1.8e11 / 1.2e11 | ✔ / ✔ / ✔ |
| N13 slope | βu/(1−u) [S] at u_i | u_i | 0.33 / 0.53 / 0.88 | ✘ / ✘ / ✔ (outward only) |
| N13 curvature | V″/V = −8u/(1−u) [S] | u_i | −0.94 / −1.50 / −2.47 | ✘ / ✔ / ✔ |

- **Clock rows** (from D2143a, anchored to ℓ_A): u_i ×/÷1.5 gives +28.6 / −10.6 Myr; b = −0.025 gives −50 Myr, and +0.025 makes the solver collapse.
- **OPEN, no equation derived:**
  - N1: rung-state masses;
  - N14: pre-inflation (E10 billiard);
  - N16: the flux → D3-charge map. The record has |M| = 9 → 46 against χ/24 = 2, with no derived scaling.
- **TRUST:** N8's ΔN_eff = 0; N11's TCC flag; N15 (a theorem, with no knob).
- **Which way the walls lean:**
  - **Pulling outward breaks** only N2: neutrino mass up to 0.088 eV crosses DESI.
  - **Pulling inward breaks:**
    - N4a: a lighter τ_q dilutes too much;
    - N5w: a lighter gravitino puts the wino under ATLAS;
    - N13: a smaller thread start is too flat for the swampland.
  - **N4b breaks in every direction** (re-annihilation caps it).
  - **The tightest walls at the base point:** N5w (+0.03), N2 (+0.09) and N4a (+0.21).
  - **Inward is the dangerous direction:** three walls break that way and only one breaks outward.

## D2144a (CENTRE, referee pass on D2144: NOT BALANCED on R44-1/2, now fixed). D2144 itself is not edited (2026-11-22 ~21:00 CT)
- **R44-1, N6.** N\* is not a free knob: N\* = 2/(1 − n_s), so pulling it moves the scored n_s by about 3σ. N6 is relabelled **"locked to n_s (no independent knob)"**. The scaling r₀(68/N\*)² is a record scaling [R], not Starobinsky's 12/N².
- **R44-2, N5w, now sourced.** Two readings:
  - **ATLAS** 2603.08315, pure-wino line: excluded up to **670 GeV** (770 expected).
  - **CMS** SUS-21-006 (2309.16823, 137 fb⁻¹): "excluded up to **650 GeV** for the wino model".

  The referee's possible 0.88 TeV figure is the ATLAS ~1 ns case, not the pure-wino lifetime. The 693 GeV wino **survives both readings** (margins +0.034 against ATLAS and +0.064 against CMS). This is still the tightest wall.
- **R44-3, N2.** The inward point (0.039 eV) is **unphysical**, because the measured splittings put the floor at 0.0587. The wall sits on the floor and its only freedom is outward. **Flag:** the DESI bound assumes ΛCDM; with w ≥ −1 it tightens, so the +0.09 margin may be optimistic.
- **R44-4, N12.** This is restated as a comparison of scales: Λ_species ≳ M_s ≥ H_inf = 5.8e12 GeV, which passes easily.
- **R44-5.** The tally "inward is the dangerous direction" is **withdrawn**, because the ×1.5 step and the in/out labels are conventions. N13's curvature verdict depends on the O(1) bar c′ = 1, and that bar is now stated.

## D2145 (CENTRE, equations for the three OPEN negative-space nodes; Danny 19:36 "make an equation for each of them"). Equations are written from standard physics plus the record; no new fits
**N1, hidden families on the empty rungs**
- **Equations:**
  - m₂/m₃ = ε_m and m₁/m₃ = ε_m², with ε_m = 0.0251/(m + 1/16) [R, rung rule; O(1) couplings smear this by ×3].
  - If its light states thermalise, each light hidden Weyl fermion adds ΔN_eff = (4/7)(7/8)(2)(10.75/g\*s(T_dec))^{4/3} = **0.047** when it decouples above the electroweak scale [S].
- **Wall:** ACT ΔN_eff < 0.14 allows **at most 2 light hidden Weyl fermions**.
- **Example** [A, illustrative]: a rung-11 family (ε = 2.3e-3) with m₃ = 12.8 GeV would have m₁ ≈ 66 keV. That is light, so it would count against the dark-radiation budget.
- **The joint this gives: N1 ↔ N8** (ΔN_eff). The empty rungs are only allowed if their light states are few, or decouple early, or are heavy.

**N14, before the beginning**
- **Equation:** N\* + ½ ln(Ω_k,i/1e-3) ≤ N_tot ≤ ln(M_P/H_inf).
  - The left side is "enough inflation", which hides initial curvature and anisotropy [S].
  - The right side is the TCC bound [literature].
- **Numbers:** the lower end is 71.5 and the upper end is 13.0. **The window is empty.** This is the N11 TCC flag reappearing at the start of time.
- **Reading:** either the TCC is wrong (an open conjecture), or the Weave's inflation needs a pre-inflation history outside it. The E10 billiard is the candidate (OPEN).

**N16, the D3 tadpole of the fold**
- **Equation:** N_D3 + ½∫G₃∧Ḡ₃ + Σ_a Q_ind(D7_a, F_a) = χ/24 [S], with χ = 48, so the budget is **2**.
- **Record:** the |M| = 9 family flux induces **46** [R], an excess of **44**. The scaling from |M| to the charge has not been re-derived here; it is an open step.
- **The B2 route:** families from intersection numbers I_ab = ∏ᵢ(n_aⁱm_bⁱ − m_aⁱn_bⁱ), with no extra D3 flux. The PS seed (D2110–D2129) closes its charge exactly that way.

**Board:** every one of the 16 nodes now has an equation. The status of the three nodes formerly marked OPEN:
- **N1:** CONDITIONAL (≤ 2 light hidden Weyl species).
- **N14:** **EMPTY WINDOW under the TCC** (FLAG, the same as N11).
- **N16:** **FAIL** (46 against 2), with B2 as the named repair.

## D2146 (CENTRE, ping-pong round 1→2 on B2; plan locked as PREREG_D2146). The families-from-intersections route on IIA T⁶/Z₆′
- **Referee confirmations:**
  - Z₆′ = (1, 2, −3)/6 is the Weave's Z6-II.
  - T₁ and T₂ are SU(3) lattices, so their complex structure is frozen (the "ρ" pin is automatic). T₃ has only a Z₂ action.
  - There is no discrete torsion.
- **Referee fixes, all folded into the lock:**
  - z2z6p.py's Z₆′ is the wrong one (it would give Z6-I), so a new builder is needed.
  - The mirror map relabels the tadpole; it does not cure it. B2 is a NEW brane content, so the scored flavour, proton and r items may move. This is pre-registered.
  - N4-seq stays OPEN: the classified D6 models carry no SUSY-breaking sector.
  - The scan must also count hidden massless states (ΔN_eff), check K-theory and the GS rank, and reject exotics.
- **Data gathered (0708.2285, read through a summariser):**
  - bulk coefficients P = (n₁n₂ − m₁m₂)n₃, Q = (n₁m₂ + m₁n₂ + m₁m₂)n₃, U = (n₁n₂ − m₁m₂)m₃, V = (n₁m₂ + m₁n₂ + m₁m₂)m₃;
  - the intersection form (ρ₁∘ρ₃ = ρ₂∘ρ₄ = 4, ρ₂∘ρ₃ = ρ₁∘ρ₄ = 2);
  - the AA bulk tadpoles Σ N(2P + Q) = 8 and Σ N(−V − bQ) = 8(1 − b);
  - the SUSY condition;
  - the fractional-cycle formula over the Z₂ fixed points on T₁ × T₃;
  - an SM example (U(3) × U(2) × U(1) × U(1) × hidden U(2), ϱ = 1/4).
- **Blocker:** the builder needs the paper's exact tables. These are Table 2 (fixed-point traversal), Table 5 (exceptional images), Eq. (2.8) (exceptional tadpoles) and Appendix D.1 (the example's wrapping numbers). The summariser cannot reproduce them verbatim. Downloading the PDF needs Danny's OK.

## D2147 (CENTRE, B2 step 2: positive control **PASS** on the first run). The T⁶/Z₆′ builder (the Weave's own Z6-II twist) reproduces Gmeiner–Honecker's published Standard Model (2026-11-22 ~21:30 CT)
- **Source.** The arXiv TeX source of 0708.2285 (Danny's OK; tar SHA-256 631a85bb…). The transcription rules were locked first (PREREG_D2146 addendum 1).
- **Code.** tools/seed/z6p.py (builder: lattice ABa, fractional cycles, intersection form, ΩR images, Π_O6, tadpoles, chirality) and tools/seed/z6p_control.py. Result: tools/seed/z6p_control.json.
- **Result.** The published SM (U(3) × U(2) × U(1)_Y × U(1)², with a hidden U(1); ABa, ϱ = 1/2):
  - **all 12 tadpole components vanish exactly** (bulk and Z₂-exceptional);
  - **all 26 published chiral numbers match.** These include 3 quark doublets (a·b′ = 3), the right-handed quarks (a·c = a·c′ = −3), b·c = b·c′ = −9, b·d = 6, b·d′ = 3, and c·d = −3, c·d′ = 3, with every Anti/Sym entry 0.

  No sign fix was needed.
- **Meaning for N16.** A tadpole-free, three-family, Standard-Model-like brane configuration exists on the Weave's own Z6-II geometry, and our builder reproduces it exactly. The tadpole FAIL (46 against 2) belongs to the |M| = 9 *flux* realisation, not to the geometry.
- **Not yet done** (the cost clause of PREREG_D2146 still applies):
  - the scan for models that also pass the hidden-sector ΔN_eff pin (this example has a hidden U(1) and many non-chiral states), the K-theory probes and the GS rank;
  - re-deriving the scored flavour, proton and r items for the chosen model.

  **N16 status: from FAIL to "B2 viable, cost pending".**

## D2132 partial result 1/3 (newest data: Planck PR4 HiLLiPoP + LoLLiPoP + PR4 lensing + 2018 low-ℓ TT + DESI DR2 + **DES-Dovekie**). **The thread does not thaw on full PR4: W is CONSISTENT with ΛCDM but does not beat it.** (2026-11-22 19:46 CT)
- **Fits:** L (ΛCDM, n_s free): χ²_eff = 7215.30, H0 = 68.12. W (Weave): χ²_eff = 7217.70, H0 = 68.20.
  - The two BOBYQA starts agree (3597.73 and 3597.90 in −log post).
  - **u_i → 0.0016**, a frozen thread that is ΛCDM-like, so the CPL fit is (−1.000, 0.000).
- **Δχ²_eff (W − L) = +2.4.** The locked rule gives **MILD TENSION** (+2 < Δ ≤ +6), but only just.
- **Block by block** (W − L):
  - HiLLiPoP high-ℓ: +2.84. This is the price of the fixed n_s = 0.9706 and the 3ν/Σm_ν/r inputs.
  - LoLLiPoP: +0.69
  - low-ℓ TT: −0.91
  - lensing: +0.71
  - DESI: −0.58
  - Dovekie: +0.25
- **Honest reading:**
  - On full PR4 the thread's late-time gain seen with compressed CMB (D2133/D2134: −4.2 to −4.5 at u_i ≈ 0.157) is **not found**. The minimiser takes u_i → 0. Either the full CMB likelihood penalises the thawing, or the gain was an artefact of the compressed priors.
  - What remains is the fixed-n_s cost on the high-ℓ spectrum.
  - **This supersedes the compressed-CMB Dovekie claim for newest-data purposes.**
- **Still running:** Pantheon+ and Union3 (L/W/C), C on Dovekie, and then the D2135 CamSpec cross-check. No verdict on the other SN sets yet.
- **Clock correction:** the times written in D2146a–D2147 ("~21:25", "~21:30 CT") are wrong. Those notes were written at about 19:40–19:45 CT.

## D2148 (CENTRE, B2 step 2b: generator control 2 **PASS after DEV-1**). The Z₆′ fractional-cycle generator regenerates all 5 published branes from wrapping numbers plus displacements and Wilson lines, all SUSY at ϱ = 1/2 (2026-11-22 ~19:58 CT)
- **First run:** a and b matched exactly; c, d and e did not. **DEV-1** was written before the rerun:
  1. **c** matched up to one global exceptional sign. That sign is a representative-orientation convention, absorbed into τ₀. A scan runs over τ₀ ∈ {0, 1}, so **the space of models does not depend on it**.
  2. **d and e:** Appendix D.1's wrapping numbers give the wrong bulk, (0, 0, −1, −1). With one sign corrected, (1, 1; 1, −2; 0, 1), they reproduce Table 13 in full, bulk and exceptional. So **0708.2285 Appendix D.1 has a typo** (m₁ for branes d and e).
- **Rerun:** **5/5 match and 5/5 SUSY.** Files: tools/seed/z6p_control2_dev1.json, tools/seed/z6p.py (generator).
- **Next (step 3, after the referee's round-4 review):** the bounded scan on ABa at ϱ = 1/2 in the locked filter order, with ΔN_eff as a dial.

## D2149 (CENTRE, B2 checks for addendum 3: **all PASS**)
- **End-to-end (the referee's DEV-1 condition).** Wrapping + σ + τ → generated cycles → control 1: all 12 tadpoles are 0 and all 26 chiral numbers match. DEV-1 is accepted.
- **R-B2-10, saturation.** The distinct SUSY non-overshooting bulk cycles on ABa at ϱ = ½ number **18 / 20 / 20 / 20** at |n|, |m| ≤ 3 / 4 / 5 / 6. **The set saturates at 20 from bound 4**, so the planned bound of 3 would have missed 2 cycles. The scan uses the full saturated set.
- **R-B2-11, representatives.** On 20 random SUSY (odd, odd) orbits, all 4 representatives (θ³ and the two-torus sign flips) give **identical** sets of fractional cycles over all σ and τ, 16 per orbit.
- **Files:** tools/seed/z6p_checks3.py and z6p_checks3.json.

## D2132 run note (2026-11-22 ~20:05 CT)
- The first batch job hit its 2-hour background cap. C (w0wa) on Dovekie and L on Pantheon+ were killed mid-fit, so neither produced a result. These are not reruns to chase results: no output exists for them.
- **Restarted in priority order** (the same script, the same lock): L and W on Pantheon+ and Union3, for the W-vs-L verdict. The C fits and the D2135 CamSpec cross-check come after, in a later job.
- **The CamSpec waiter was stopped** before it had started any fit, so the cores go to the D2132 verdict first.

## D2150 (CENTRE, the g_s restructure triangulation; lock PREREG_D2150 after ping-pong round 1). **Verdict by the locked rule: option F. Keep S = ρ and reinterpret it as the constant-coupling F-theory point; 5 scored derivations are flagged "unprotected". Option D (fibre inflation) is the backup.** (2026-11-22 ~21:10 CT; referee check pending)

| option | n_s (margin) | r (margin) | g_s control | min margin | scored items moved |
|---|---|---|---|---|---|
| D, fibre inflation at r = 0.005 | 0.9711 (+1.04) | 0.005 (+1.97) | +0.92 | **+0.92** | 7 (n_s, r, the A = 7.30 link, the m3/2/wino chain, τ_q, α_GUT, a K3-fibre blow-up) |
| **F, F-theory point at ρ** | 0.9706 (+0.87) | 5.4e-4 (+4.20) | replaced by protection | **+0.87** | **0** (5 unprotected) |
| A, null | 0.9706 (+0.87) | 5.4e-4 (+4.20) | −0.84 | −0.84 | 0 |
| B, the D1398 U₃ variant | 0.9606 (−2.47) | 1.56e-3 | +0.92 | −2.47 | 4 |
| D, fibre inflation at r = 0.01 | 0.9592 (−2.94) | 0.01 | +0.92 | −2.94 | 7 |

- **The rule's tie-break decides it.** D at r = 0.005 and F differ by only 0.05 (< 0.3), so the option that moves fewer scored items wins: **F**.
- **The 5 "unprotected" derivations under F** (they relied on weak-coupling perturbation theory and must be redone in F-theory language):
  1. α_GUT from f_vis = T + 9S;
  2. the |M| = 9 magnetised-D7 family flux;
  3. the D-instanton μ-term weight;
  4. the Yukawa normalisations;
  5. the KKLT W₀–volume–m3/2 chain.

  The E(S,3/2) plateau that drives inflation is exact in S (SL(2,Z)), so it is protected.
- **Joint with B2.** The family-flux item (2) is already scheduled to be replaced by brane crossings (D2146–D2149). In F-theory, constant-coupling 7-brane stacks at ρ are E6/E8-type, so the matter sector would become an F-theory one. That is the natural home for both pieces at once.
- **Dead or disfavoured.** E is dead. B (the D1398 variant) and high-r D are 2.5–3σ against ACT's n_s. Other B variants stay OPEN.
- **What D would cost.** Fibre inflation would trade the Weave's own prediction (r = 5.4e-4, the same A at both ends) for the literature's r ≈ 0.005, which LiteBIRD could test, and it needs a K3-fibred geometry that T⁶/Z6-II does not have.

## D2150a (CENTRE, referee pass on D2150: NOT BALANCED, accepted). **The verdict "F wins" is WITHDRAWN. No restructure cleanly wins; the strong coupling stays the core open problem.** D2150 itself is not edited (2026-11-22 ~21:15 CT)
- **R50-1.** F's unprotected list was about half complete. Beyond the five already listed, it also takes in:
  - n_s and r (through K = −ln(S + S̄) and β);
  - the thread's potential and w(a);
  - m3/2 and the wino (AMSB);
  - the moduli cosmology: Γ(τ_q), T_d, D, T_R, τ_3/2;
  - M_X and τ_p;
  - Koide/TM1/δ_CP, the seesaw Σm_ν and η_B;
  - the tadpole budget, which in F-theory becomes χ(Y₄)/24.

  That makes **about 14 unprotected items**.
- **R50-2.** E(S,3/2) is exact *as a function*. But A = 16ζ(2)/(3ζ(3)) is the ratio of its two weak-coupling terms, and at Im S ≈ 0.87 the D-instanton terms are O(1). So **A, β, n_s, r and the thread are "unprotected near the knot"**. My statement that "the inflation plateau stays protected" is withdrawn.
- **R50-3.** A constant-coupling F-theory point freezes τ through the 7-brane configuration, so S cannot be a rolling inflaton that ends there. F needs an explicit mechanism, such as 7-branes collapsing into an E6 stack as inflation ends, or a re-identified inflaton. **This is OPEN.**
- **R50-4.** D's r = 0.005 point implies N\* ≈ 69. LVS fibre inflation with volume-modulus reheating gives N\* ≈ 45–55, so n_s ≈ 0.960–0.964 and r ≈ 0.008–0.012 (the referee's recollection of the literature; to be sourced). At a self-consistent N\*, **D fails** against ACT's n_s (≈ −2.9 margin).
- **R50-5.** The tie-break rewarded relabelling. With moved and unprotected items both counted, F is not ahead.
- **Restated verdict:**
  - **A is the defended null:** honest strong coupling, with ~14 derivations flagged.
  - **F is CONDITIONAL** on an R50-3 mechanism.
  - **D fails.**
  - **B** (other variants) and **F's mechanism** are the open research directions.
- **Where we stand on g_s:** the Weave does not yet have a weak-coupling home. Saying so plainly is part of the paper.

## Run note: the PC is now in use (Danny is home, 20:56 "get the test ready on the computer and have it run"), 21:03 CT
- **12 fits launched on Danny's PC** (16 cores; each fit single-threaded at BelowNormal priority):
  - the full D2135 CamSpec-NPIPE grid (L/W/C × Dovekie/Pantheon+/Union3);
  - the three D2132 w0wa (C) fits on HiLLiPoP.
- **The same locked script.** tools/weave_pc/weave_lcdm_pr4.py differs from field_tests/weave_lcdm/weave_lcdm_pr4.py only in its paths. It already contains the D2132 DEV u_i reference-range fix.
- **Environment:** Danny's existing venv312 (Cobaya 3.6.2, CAMB 2.0.5, the same versions as the cloud).
  - Added from the cloud: the PR4 likelihood packages (planckpr4lensing 1.0.3, hillipop 4.3.1, lollipop 4.1.2), copied with SHA-256 checks.
  - Added from the cloud: the planck_2020 data.
  - CamSpec runs on the PC's own NPIPE data.
- **Still in the cloud:** L/W on Pantheon+ and Union3 (HiLLiPoP), and the Z₆′ scan.
- **CubeMind v5b** (tools/weave_cm_v5b), installed with backups. A learn-loop step watches the PC results folder and weave_data/lcdm. For each new fit it:
  - stores the fit as EVIDENCE;
  - computes the locked W-vs-L verdict with the new tool weave_verdict;
  - queues blind re-derivations (Δχ², and w today via weave_wtoday) into calc_queue, so CubeMind derives each one itself and is graded mechanically.

  Tested on a mock first, where a duplicate-record bug was found and fixed before install.

## D2152 (CENTRE, B2 step 3a: visible-sector scan on the Weave's own Z6-II = T⁶/Z₆′, lattice ABa at ϱ = ½; PREREG_D2146 addendum 4). **Control 3 PASS: the published SM is found among the survivors. The scan stopped at its 90-minute cap (PARTIAL).**
- **Bulk configurations:** 6,522 satisfy both bulk tadpoles, with up to 2 hidden stacks.
- **Pairs passing the doublet and no-exotic filters:** 118,272 (a, b) pairs, with 3 quark doublets and Sym_a = 0.
- **Survivors at the cap:** **3,701,120** configurations pass every step-3a filter: 3 quark doublets, 6 right-handed quarks with one sign, all 12 tadpoles cancelled (bulk and exceptional). The count includes relabellings (c ↔ d, the hidden orderings, equivalent τ₀ signs). The **first 2,000** are stored in tools/seed/z6p_scan3a.json.
- **Reading:** on the Weave's own geometry, charge-cancelling brane configurations that carry the Standard Model's quark sector are **plentiful, not rare**. This matches Gmeiner–Honecker's ~10¹⁵ MSSM-like count.
- **Not yet applied (step 3b):** hypercharge masslessness and the GS rank, lepton counts, K-theory probes, and the dials (hidden massless states / ΔN_eff, Yukawa texture, hidden β-functions).
  - **Step 3b runs on a locked random sample:** the 2,000 stored survivors.
  - **Lesson for the next scan:** a full enumeration needs canonical-form deduplication first.

## D2153 (CENTRE, engine tally: every finished fit now counts in CubeMind; PREREG_D2153 locked 21:52 CT before the pending fits finished)
Danny (21:47): "Can we plug these tests into the engine and have it count." Done: weave_verify.weave_tally() rebuilds weave_data/lcdm/WEAVE_TALLY.json each step (installed on the PC CubeMind, backup .bak_d2153). One entry = W and L on the same likelihood set, scored by the D2132 classes; dchi2 is NOT summed across entries (shared Planck/ACT/SPT, DESI and SN data would be counted several times). Headline entry = PR4 HiLLiPoP + DESI DR2 + DES-Dovekie.
Tally at 21:55 CT: 1 entry, desdovekie dchi2 = +2.40 -> MILD TENSION. Pending: CamSpec x 3 SN sets, HiLLiPoP Pantheon+/Union3 (cloud), ACT DR6 lite and SPT-3G D1 lite on Dovekie. C_union3_camspec crashed at start (CamSpec cache lock, sibling process); counts as not run (DEV note in PREREG_D2135_DEVIATIONS).

## D2154 (CENTRE, D2132 second entry: full PR4 HiLLiPoP + DESI DR2 + Pantheon+; locked script, run once after the DEV start-range fix). **dchi2(W-L) = +2.46 -> MILD TENSION (D2132 rule). Tally now 2 entries, both mild tension.** (2026-11-22 ~22:05 CT)
L: chi2_eff 6986.34, H0 68.36 region (n_s free 0.968). W: chi2_eff 6988.80, H0 67.42, u_i = 0.143 (thread ACTIVE here, unlike Dovekie where u_i -> 0.002).
Per-likelihood W-L: DESI BAO -5.17, Pantheon+ -2.13, lowlE -0.95, lowl TT -0.61 (the thread helps the late-time data) vs HiLLiPoP TTTEEE +6.66, PR4 lensing +2.70 (the high-l CMB pays, mostly for fixed n_s = 0.9706 and the fixed neutrino sector).
Reading: the same pattern as Dovekie, stronger. The late-universe data pull toward the thread; Planck high-l pulls back. Not summed with D2132 (shared CMB/BAO). Pending: W union3 (cloud, running), CamSpec and ACT/SPT (PC).

## D2154a (correction to D2154, record-side): L Pantheon+ H0 is 67.85 (JSON point.H0), not "68.36 region". D2154 itself is not edited.

## D2155 (CENTRE, pre-publication referee pass on "The Weave: Predictions and Postulates", ~22:15 CT): NOT BALANCED -> 7 must-fix + 6 should-fix, all applied to the doc (rev 34) and the Zenodo draft description.
Fixed: (1) "consistent with standard cosmology" -> mild tension on both finished SN sets (D2132 rule; Union3 pending); (2) "one fewer free parameter" -> same count (u_i replaces n_s; L also fixes sum m_nu); (3) "five numbers fixed by theory" -> n_s fitted once and frozen, running/r follow, neutrino input chosen, N_eff standard; (4) "every result locked and refereed" -> most, with listed exceptions (wino not blind D2141, Hubble map D2136, TCC unlocked, PR4 fits numbers-only referee); (5) alpha_s 0.1158 -> 0.1147 (-3.7 sigma, D1897/D1901); (6) walls 10/16 -> 9/16 pass, 3 fail (N4 per D2140a, N10, N16); (7) Pantheon+ net +2.46 split: likelihoods +0.50, HiLLiPoP nuisance Gaussian priors +1.96 (Dovekie: likelihoods +3.0, priors -0.6). Should-fix: reduces-to-LCDM only on Dovekie; TM1 sin^2 theta12 relabelled I; proton lifetime mostly beyond Hyper-K/DUNE (D1797); r 5.4 vs 5.7 not testable soon (D2140a); running likely below planned reach; CMB-S4 removed (US support ended July 2025, Scientific American); postulate 3 "might be addressed" (N4-seq open, D2146); postulate 1 hints -> "patterns consistent with it, not evidence" (D2143a).

## D2156 (CENTRE, pulsing Loom on tonight's newest data; PREREG_D2156, run once; tools/loom/resonance_d2156.py VC + VN). **No inner node knocked off balance; the late-universe layer now has a scale and does not lock (-0.46).** (2026-11-22 ~22:33 CT)
- VC (baseline, unchanged) reproduced: locks [1, 2, 5, 6, 7, 8] in every breath; L10 fails on H0 (-3.39 inhale / -1.04 exhale with dNeff 0.395, which then breaks the ACT dNeff wall -1.04). Fits spent: MN, m3/2, T_R, split.
- VN (three new scales): L6 n_s vs P-ACT-LB = +0.93 (holds; plus 1.21 vs SPA+DESI); L8 dark-baryon window [3, 15] GeV with the wino share taken out = +0.59 (holds); L9 thread_PR4 = 2 - 2.46 = -0.46 (L9 has no dial, so it cannot lock: the data scale is fixed). inner_unlocked = [] in every breath: no node that locked before fell out when the newest scales were added.
- Unchanged weak points the scales show: L4 rung agreement -0.003 (never locks); L7 alpha_s locks ONLY by spending the split-stack dial (a fit), consistent with the preprint's "alpha_s fail" for the single-stack model; L10 H0 fails both breaths.
- Matches the stated expectation except L7 (expected fail; it locks through the split fit; the paper reports the no-split value, which is the honest one).

## D2157 (housekeeping, Danny 22:26-22:27: "CubeMind failing on the email", fix and speed up). The failure emails were GitHub's "tools" CI, failing on every push since 20 Nov.
- Cause: tools/ladder/ladder.py check requires a MAP line in every D-note from D739 on; MAP lines lapsed from D1740 (the theory/map ladder was not carried into the Weave era), so ~320 notes failed the check. No physics test was failing.
- Fix (recorded, not silent): MAP_UNTIL = 1739. The check is unchanged for D739..D1739; later notes track status in balance boards and field_tests/balance/BALANCE_LEDGER.md. No D-note was edited. Ladder tests 7/7 pass; ladder check OK; tracker runs.
- Speed: the workflow now cancels an older run when a newer push arrives (concurrency group), and caches pip downloads.

## D2144b (correction to D2144a, record-side, from the W2 outside-world referee 22:35 CT): the "CMS 650 GeV" wino limit could not be confirmed in CMS SUS-21-006 text; the pure-wino (0.2 ns) CMS figure in 2004.05153 is 474 GeV. ATLAS 2603.08315 (2026) gives 670 GeV observed, 770 GeV expected, so the Weave's 693 GeV sits inside ATLAS's expected sensitivity and passes only through a downward fluctuation. The preprint now says this. D2144a is not edited.

## D2158 (CENTRE, D2135 CamSpec cross-check, first entry: Planck PR4 CamSpec NPIPE + LoLLiPoP + PR4 lensing + DESI DR2 + Pantheon+; PC runs, locked script, run once). **dchi2(W-L) = -3.80 -> PREFERRED by the D2132 rule, BUT the minimiser is not clean on this pair: treat as NOT ROBUST.** (2026-11-22 ~22:45 CT)
- L: chi2_eff 12033.95, H0 68.07, n_s 0.966. W: chi2_eff 12030.16, H0 67.34, u_i = 0.140 (thread thaws, as with HiLLiPoP + Pantheon+).
- Per likelihood W-L: CamSpec high-l +2.42 (vs +6.66 with HiLLiPoP), low-l TT -0.92, lowlE -0.03, lensing -0.48, DESI BAO -1.79, Pantheon+ -2.58. Likelihoods alone -3.38; nuisance priors -0.42.
- Minimiser warnings (logs): L "modest spread in minima" 6011.92 vs 6012.49 in -log posterior (1.13 in chi2); W "some minimizations failed" (one of two runs). The minimiser uncertainty (~1 in chi2) is smaller than the 3.8 gap but not negligible, and W rests on one converged run.
- Reading: the high-l cost of the fixed inputs is much smaller with CamSpec (+2.4) than with HiLLiPoP (+6.7), so on CamSpec + Pantheon+ the thread's late-time gain wins. This is ONE robustness entry; the headline (HiLLiPoP + Dovekie, +2.4) is unchanged. Entries are never summed. Also finished: L CamSpec on Dovekie (12259.08) and Union3 (10652.75); their W partners still running.

## D2158a (referee round 7 on D2158): the pre-registered D2135 label applies and was missed. HiLLiPoP (+2.46) and CamSpec (-3.80) on Pantheon+ differ in sign and by 6.26 >= 3, so the Pantheon+ entry is **"CMB-likelihood dependent"** (PREREG_D2135 lines 16-17). The preprint now uses that label, with the minimiser caveat as a second reason for caution. D2158 is not edited.

## D2159 (CENTRE, pattern read across the three finished W/L pairs; POST-HOC observation, not a test, not evidence) (22:45 CT)
| pair | dchi2 | u_i | H0 W/L | omch2 W/L | high-l | lensing | BAO | SN |
|---|---|---|---|---|---|---|---|---|
| HiLLiPoP+Dovekie | +2.40 | 0.0016 | 68.20/68.12 | 0.1177/0.1179 | +2.84 | +0.71 | -0.58 | +0.25 |
| HiLLiPoP+Pantheon+ | +2.46 | 0.143 | 67.42/67.85 | 0.1172/0.1184 | +6.66 | +2.70 | -5.17 | -2.13 |
| CamSpec+Pantheon+ | -3.80 | 0.140 | 67.34/68.07 | 0.1174/0.1179 | +2.42 | -0.48 | -1.79 | -2.58 |
Patterns: (1) the SUPERNOVAE set the thaw (u_i 0.002 vs 0.14) and the CMB likelihood does not move it (0.143 vs 0.140); (2) the CMB LIKELIHOOD sets the price (high-l +6.7 vs +2.4); (3) a seesaw with omch2 as the fulcrum: when the thread thaws, omch2 drops ~0.001 and BAO/SN gain is paid in high-l + lensing, more steeply for HiLLiPoP; (4) thawing always lowers H0 (by 0.4-0.7), so it worsens the Hubble tension; (5) L's n_s sits at 0.966-0.969 in all three, below the frozen 0.9706, so the fixed n_s cost is present in every pair. Testable next (to lock before running): Union3 should thaw (it pulled toward w > -1 in DESI DR2); the CamSpec Dovekie pair should stay frozen with a small cost.

## D2161 (RIGHT, quick systematics test, PREREG_D2161, run once, 37 s). **Unequal-neutrino axis: CLOSED at the background level.** (23:08 CT)
Compressed CMB + DESI DR2 + DES-Dovekie (referee_indep/fit.py): chi2(L, single 0.06 eV) = 1648.229; chi2(Lnu, 3 normal-ordered, 0.0587 eV) = 1648.233; delta = +0.004 (|delta| < 0.5 -> CLOSED by the lock). H0 68.463 vs 68.466, r_drag 147.127 vs 147.121 Mpc. Limitation (stated at lock): compressed CMB does not see lensing or high-l, where neutrino mass also enters; a full PR4 refit stays queued for after the publish.

## D2162 (CENTRE, D2132 third entry: PR4 HiLLiPoP + DESI DR2 + Union3, run once after the cap DEV). **dchi2 = -1.65 -> CONSISTENT.** Plus a finding that changes how every entry reads: **the minimiser scatter is 3-4 in chi2 on every fit.** (2026-11-22 ~23:12 CT)
- L: chi2_eff 5607.93, H0 68.36, n_s 0.9726. W: chi2_eff 5606.28, H0 67.24, u_i = 0.148 (thaws). Likelihoods -2.72, nuisance priors +1.07. Per likelihood: HiLLiPoP -1.26, lowlE -0.18, lowl TT -0.12, lensing +2.48, DESI +0.62, Union3 -4.25.
- D2132 headline rule: "CONSISTENT/PREFERRED only if it holds on all three sets" -> NOT met (+2.40, +2.46, -1.65): headline stays mild tension on 2 of 3 sets, consistent on Union3. Pre-registered Dovekie reading (R31-1): W-L = +2.40 > -6 -> **"SN-calibration dependent"** (applies; was not stated before).
- **Minimiser scatter (both BOBYQA runs, from the logs, in chi2 = 2 x -log posterior):** L Pantheon+ 3.6, L Union3 3.2, W Pantheon+ 3.6, W Union3 4.3 (CamSpec: L 1.1, W one run failed). The scored value is the better of two, but two runs disagreeing by 3-4 means the true minimum may be lower still for either model. Every dchi2 tonight (+2.4, +2.5, -1.7, -3.8) is inside this scatter. **The W-vs-L verdicts are not resolved at the +-2 level by best-of-2.** The more-starts systematics run is now the first thing to do, not an option.
- D2160 forecast scoring (partial, this pair): F1 (Union3 thaws, HiLLiPoP half) PASS (0.148 > 0.05); F3 (thaw lowers H0) PASS (67.24 < 68.36); F5 (fulcrum, omch2 W < L) **FAIL** (0.11736 vs 0.11724); F4 waits for CamSpec Union3; F2 waits for CamSpec Dovekie. Here the high-l is not the price: L's own n_s came out 0.9726, above the frozen 0.9706, so fixing n_s costs nothing on Union3 (-1.26), and the price moves to lensing (+2.48).

## D2164 (DEEP, PREREG_D2164, run once): **A = 7.30 is PROTECTED at the knot: the exact D-instanton sum shifts it by only -1.6%.** (2026-11-22 ~23:22 CT)
- Exact E(S, 3/2) at S = ρ (x = 1/2, y = √3/2, so g_s = 1/y = 1.155): leading 2ζ(3)y^{3/2} = 1.9375; subleading 4ζ(2)y^{-1/2} = 7.0704; D-instanton sum I(ρ) = -0.1152; total 8.8927. δ = I/subleading = **-0.0163** -> A_eff = 7.18 (vs 7.298). At S = i: δ = +0.0076.
- Validation: SL(2,Z) invariance E(S) = E(-1/S) to 30 digits at S = 0.31 + 0.83i; independent brute-force lattice sum Σ' y^{3/2}/|m + nS|³ at ρ gives 8.8888 (N = 1500) and 8.8908 (N = 3000), extrapolating as 1/N to 8.8927, matching.
- Reading: even at g_s ≈ 1.15 the instanton corrections at ρ are small (e^{-2π y} ≈ 0.004), because the knot's Im S = √3/2 is not small. So the ~14 "unprotected" D2150a items keep their numbers to about 1.6% wherever A enters linearly. What this does NOT supply: the mechanism that holds the coupling at ρ (F-theory constant-coupling reading stays OPEN). The strong-coupling hole shrinks from "numbers may be meaningless" to "numbers hold to ~2%, mechanism owed".

## D2165 (DEEP, PREREG_D2165, run once): **the dark photon HAS A HOME on the published Z6-II model: the hidden stack's U(1)_e stays massless and has no chiral states with the visible sector.** (2026-11-22 ~23:30 CT)
- Stueckelberg kernel of sum_a x_a N_a (Pi_a - Pi_a'): rank 2 of 5, so 3 massless directions: Q_c; (1/3)Q_a + Q_d (a B-L-type direction); Q_e (the hidden stack).
- Control PASS: hypercharge Y = (1/6)Q_a + (1/2)Q_c + (1/2)Q_d = (1/2)Q_c + (1/2)[(1/3)Q_a + Q_d] lies in the massless space.
- The chiral spectrum has no a-e, b-e, c-e or d-e entries, so U(1)_e couples to the Standard Model only through kinetic mixing: exactly the dark-photon structure the Weave needs (D1685/D2100 dark U(1)).
- Still owed: (1) its mass, from a dark Higgs, has to land at 0.3-10 GeV; (2) the mixing epsilon is not derived; (3) a massless hidden U(1) and the extra massless B-L direction count as radiation unless broken (the DeltaN_eff check, step 3b); (4) this is the published example model, not yet the scan survivors.

## D2164a (online + independent referee on D2164, NOT NULL, accepted): "A protected to ~1.6%" is WITHDRAWN as stated. D2164 is not edited.
- Numbers confirmed independently (E(ρ) = 8.892745100397; invariance to 2e-25; instanton part -0.11518).
- But at ρ the "subleading" term (7.07) is 3.65x the "leading" one (1.94): the weak-coupling ordering is inverted, and A (a ratio of expansion coefficients) is not uniquely defined. A_eff = A(1+δ) was a convention; assigning the instanton part to the leading term instead gives δ = -5.9%, A_eff ≈ 7.76, which is SHIFTED by the lock's own rule. Attribution-free statement: the exact E differs from its two-term form by -1.3% at ρ.
- Restated verdict: the function is close to its two-term form at the knot; A's meaning at strong coupling stays OPEN (shift between -1.6% and about +6% depending on convention); the mechanism stays OPEN. The paper row and the field map say this.

## D2165a (referee on D2165, NOT NULL, accepted). D2165 is not edited.
- Q_c and Q_e are massless trivially (Pi_c = Pi_c', Pi_e = Pi_e'); such a stack is U(1) only if displaced from the O6-plane, otherwise it enhances to SO/Sp: owed check. The only non-trivial massless direction is (1/3)Q_a + Q_d, "B-L-like, pending a charge-sign check" (GH 0806.3039 reports massless B-L in some examples; not confirmed for this one).
- "No e-sector chiral states" means no NET chiral matter; the vector-like spectrum is not computed, and vector-like states plus massive string modes generate kinetic mixing (Abel et al. 0803.1449).
- "Dark photon HAS A HOME" is WITHDRAWN. Restated: the model has a massless hidden U(1)_e; it is a dark-photon CANDIDATE only if a mass (dark Higgs or Stueckelberg) and a kinetic mixing are supplied; neither is derived. Unbroken, it is dark radiation.

## D2166 (CENTRE, the Standard Model pulsed through the Weave, centre outward; consistency map, not a test; tools/loom/sm_pulse.py). **Inhale (no dials): 8 of 21 SM items come out of the Weave; exhale (dials spent): 17 of 21; 1 fails (alpha_s), 3 missing.** (2026-11-22 ~23:40 CT)
| layer | SM items | inhale (P/S/R) | exhale (+F/I) | fail | missing |
|---|---|---|---|---|---|
| L1 torus (quarks) | 5 | 0 | 3 | 0 | 2 (top Yukawa scale, CKM phase) |
| L2 pyramid (neutrinos) | 6 | 3 (lightest ~0, delta_CP, m_bb) | 6 | 0 | 0 |
| L3 turnover (leptons) | 2 | 1 (m_tau from Koide) | 2 | 0 | 0 |
| L5 fold (Higgs) | 2 | 0 | 1 (m_h at tan beta 1.9) | 0 | 1 (the vev) |
| L7 forces | 6 | 4 (gauge group, 3 families, Higgs pair: borrowed from the Gmeiner-Honecker model; theta-bar = 0) | 5 | 1 (alpha_s -4.2 sigma) | 0 |
Triangulation (three readers): records (statuses above), data (PDG tau mass 1776.93 +- 0.09 MeV, fetched: the Koide value 1776.969 sits +0.43 sigma; JUNO sin^2 theta12 +1.1 sigma; alpha_s -4.2 sigma), engine (CubeMind weave_koide reproduces Q). Reading: the Weave's real outputs on the SM are structural (borrowed brane model) plus a handful of relations; the quark sector rides on one fitted coefficient, the Higgs sector on one tuned angle, and the electroweak scale and top Yukawa are not derived. Weakest layer: L1 (0 of 5 without dials).
